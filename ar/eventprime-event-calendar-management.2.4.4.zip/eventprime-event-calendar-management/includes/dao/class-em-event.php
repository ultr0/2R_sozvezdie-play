<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class EventM_Event_DAO extends EventM_Post_Dao
{
    public function __construct() {
        parent::__construct(EM_EVENT_POST_TYPE);
    }
    
    public function create($event,$id=0)
    {  
        if ($id>0) 
        {
            $event['ID']= $id;
            $id = wp_update_post($event);
        }
        else 
            $id = wp_insert_post($event);
        
        return $id;
    }
    
     public function save($model)
     {  
        return parent::save($model);
     }
     
    /**
     * 
     * @param Event ID $id
     * @param Type ID $type
     */
    public function set_type($id,$type)
    {
        wp_set_object_terms($id, $type, EM_EVENT_TYPE_TAX, false);
    }
    
    /**
     * 
     * @param Event ID $id
     * @param Venue ID $type
     */
    public function set_venue($id,$venue)     
    {  
        wp_set_object_terms($id, $venue, EM_EVENT_VENUE_TAX, false);
    }
    
    public function remove_venue($id,$tax){
        wp_remove_object_terms($id,$tax,EM_EVENT_VENUE_TAX );
    }
    
    public function set_performer($id,$performer)    
    {  
        update_post_meta($id,EM_PERFORMER_POST_TYPE, $performer,  false);
       
    }
   
    
    public function set_thumbnail($id,$img_id)
    {
        set_post_thumbnail($id, $img_id);
    }

    // Get all the events  
    public function get_events($args = array()) {
        $defaults = array(
            'post_status' => 'any',
            'meta_key' => 'em_start_date',
            'orderby' => 'meta_value_num',
            'order' => 'ASC',
            'post_type' => EM_EVENT_POST_TYPE,
            'numberposts' => -1,
        );
        $args = wp_parse_args($args, $defaults);
        $posts = get_posts($args);
        return $posts;
    }
    
     public function get_past_events(){
         $filter = array(
            'orderby' => 'date',
            'order' => 'DESC',
            'post_status'=> 'publish',
            'meta_query' => array(// WordPress has all the results, now, return only the events after today's date
                'relation' => 'AND',
                array(
                    'key' => em_append_meta_key('start_date'), // Check the start date field
                    'value' => current_time( 'timestamp' ), // Set today's date (note the similar format)
                    'compare' => '<=', // Return the ones less than today's date
                    'type' => 'NUMERIC,' // Let WordPress know we're working with numbers
                ),
                array(
                    'key' => em_append_meta_key('end_date'), // Check the start date field
                    'value' => current_time( 'timestamp' ), // Set today's date (note the similar format)
                    'compare' => '<=', // Return the ones greater than today's date
                    'type' => 'NUMERIC,' // Let WordPress know we're working with numbers
                )                
            ),
            'post_type' => $this->post_type);
         
         return $this->get_events($filter);
     }

    // Get upcoming events
    public function get_upcoming_events() { 
        $filter = array(
            'meta_key' => em_append_meta_key('start_date'),
            'orderby' => 'meta_value_num',
            'numberposts' => -1,
            'order' => 'ASC',
            'post_status' => 'publish',
            'meta_query' => array('relation' => 'AND',
                array(
                    array(
                        'key' => em_append_meta_key('hide_event_from_events'),
                        'value' => '1', //
                        'compare' => '!='
                    ),
                    array(
                        'relation' => 'OR',
                        array(
                            'key' => em_append_meta_key('start_date'),
                            'value' => current_time('timestamp'),
                            'compare' => '>=',
                        ),
                        array(
                            'key' => em_append_meta_key('end_date'),
                            'value' => current_time('timestamp'),
                            'compare' => '>=',
                        )),
                    array(
                        'key' => em_append_meta_key('hide_event_from_calendar'),
                        'value' => '1',
                        'compare' => '!='
                        )
                    )
            ),
            'post_type' => $this->post_type);

        return $this->get_events($filter);
    }
    
    
      public function get_upcoming_events_calendar() { 
        $filter = array(
            'meta_key'=> em_append_meta_key('start_date'),         
            'orderby' => 'meta_value_num',
            'numberposts'=>-1,
            'order' => 'ASC',  
            'post_status'=> 'publish',          
            'meta_query' => array('relation'=>'AND',// WordPress has all the results, now, return only the events after today's date
                array('relation'=>'AND',
                array(
              
                array(
                                        'key' => em_append_meta_key('hide_event_from_events'), 
                                        'value' => '1', //
                                        'compare' => '!='
                 ), 
                array(   
               'relation' => 'OR',
                array(
                    'key' => em_append_meta_key('start_date'), // Check the start date field
                    'value' => current_time( 'timestamp' ), // Set today's date (note the similar format)
                    'compare' => '>=', // Return the ones greater than today's date
                     // Let WordPress know we're working with numbers
                ),
                array(
                    'key' => em_append_meta_key('end_date'), // Check the start date field
                    'value' => current_time( 'timestamp' ), // Set today's date (note the similar format)
                    'compare' => '>=', // Return the ones greater than today's date
                     // Let WordPress know we're working with numbers
                )),
                array(
                'key'     => em_append_meta_key('hide_event_from_calendar'),
		'value'   => '1',
                'compare' => '!='            
               )),
                                  array(    
                                 'relation' => 'OR',
                                    array(
                                   'key' => em_append_meta_key('parent_event'), 
                                   'value' => 0, 
                                   'compare' => '=', 
                                   'type' => 'NUMERIC,'
                                    ),
                                    array(
                                        'key' => em_append_meta_key('parent_event'), 
                                        'compare' => 'NOT EXISTS',  
                                   )
                                 )
                    
                    )),   
            'post_type' => $this->post_type);
        
       
        return $this->get_events($filter);
        
    }
    
    public function get_venue($event_id)
    {
        $terms = wp_get_post_terms($event_id, EM_VENUE_TYPE_TAX);
        foreach($terms as $term){
            if($term->taxonomy==EM_VENUE_TYPE_TAX){
                return $term;
            }
        }
        return null;
    }
    
    public function get_type($event_id)
    {
        $terms = wp_get_post_terms($event_id, EM_EVENT_TYPE_TAX);
        foreach($terms as $term){
            if($term->taxonomy==EM_EVENT_TYPE_TAX){
                return $term;
            }
        }
        return null;
    }
    
    public function available_seats($event_id)
    {
        $sum= $this->booked_seats($event_id);
        $capacity= absint(em_get_post_meta($event_id, 'seating_capacity', true));
        if(!empty($capacity))
        {   
            if( $capacity>0)                  
             return $capacity-$sum;
        }
        return 99999999;  
    }
    
    
    public function booked_seats($event_id) {  
        //return em_get_post_meta($event_id, 'booked_seats', true, true);
        
        $args = array(
            'numberposts' => -1,
            'post_status'=> 'completed',
            'post_type'=> EM_BOOKING_POST_TYPE,
            'meta_key' => em_append_meta_key('event'),
            'meta_value' => $event_id,
        );
        
        $booking_posts = get_posts($args);
        $booked_seats = 0;
        foreach ($booking_posts as $post) {
            $order_info = em_get_post_meta($post->ID, 'order_info');
            if(!empty($order_info) && isset($order_info[0]['quantity'])){
                $booked_seats = $booked_seats + $order_info[0]['quantity'];
            }
        }
        return $booked_seats;
    }
    
    public function get($id)
    {
        $post= empty($id) ? 0 : get_post($id);
          if(empty($post))
              return new EventM_Event_Model(0);
        
        $event= new EventM_Event_Model($id);
        $meta= $this->get_meta($id,'',true);
        if(is_array($meta)){ 
            foreach($meta as $key=>$val) {
                $key= str_replace('em_','',$key);
                if (property_exists($event, $key)) {
                    $event->{$key}= maybe_unserialize($val[0]);
                } 
            }
        }
        
        $event->id= $post->ID;
        $event->name=$post->post_title;
        $event->slug=$post->post_name;
        $event->description=$post->post_content;
        $event->status=$post->post_status;
        $event->user=$post->post_author;
        
        $event = apply_filters('eventprime_load_into_event_model', $event, $post);
        return $event;
    }
    
    public function get_events_by_venue($venue_id){
        $filter = array(
            'post_status' => 'any',
            'posts_per_page' => '-1',
            'tax_query' => array(array('taxonomy' => 'em_venue', 'field' => 'term_id', 'terms' => $venue_id)),
            'post_type' => $this->post_type);

        $posts= $this->get_events($filter);
        $events= array();
        foreach($posts as $post){
            $events[]= $this->get($post->ID);
        }
        return $events;
    }
    
    public function get_upcoming_events_by_venue($venue_id) {
        $filter = array(
            'meta_key' => em_append_meta_key('start_date'),
            'orderby' => 'meta_value_num',
            'order' => 'ASC',
            'post_status' => 'publish',
            'posts_per_page' => '-1', // Let's show them all.  
            'meta_query' => array(// WordPress has all the results, now, return only the events after today's date
                array(
                    'relation' => 'AND',
                    array(
                        'key' => 'em_venue',
                        'value' => $venue_id,
                        'compare' => '='
                    ),
                    array(
                        'key' => em_append_meta_key('hide_event_from_events'),
                        'value' => '1', //
                        'compare' => '!='
                    ),
                    array(
                        'relation' => 'OR',
                        array(
                            'key' => em_append_meta_key('parent_event'),
                            'value' => 0,
                            'compare' => '=',
                            'type' => 'NUMERIC'
                        ),
                        array(
                            'key' => em_append_meta_key('parent_event'),
                            'compare' => 'NOT EXISTS',
                        )
                    )
                )
            ),
            'post_type' => $this->post_type
        );

        $posts= $this->get_events($filter);
        $events= array();
        foreach($posts as $post){
            $events[]= $this->get($post->ID);
        }
        return $events;
    }
    
    public function event_count_by_type($type_id){
        return count($this->events_by_type($type_id));
    }
    
    public function events_by_type($type_id) {
        $args = array(
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'post_type' => EM_EVENT_POST_TYPE,
            'meta_key' => em_append_meta_key('start_date'),
            'orderby' => 'meta_value_num',
            'order' => 'ASC',
            'meta_query' => array(
                array(
                    'relation' => 'AND',
                    array(
                        'key' => EM_EVENT_TYPE_TAX,
                        'value' => $type_id,
                        'compare' => '='
                    ),
                    array(
                        'key' => em_append_meta_key('hide_event_from_events'),
                        'value' => '1',
                        'compare' => '!='
                    )
                )
            )
        );
        $events = $this->get_events($args);
        return $events;
    }

    public function get_bookings_by_user_id_event_id($user_id, $event_id){ 
        $args = array(
           'orderby' => 'date',
           'order' => 'DESC',
           'post_status'=> 'completed',
           'meta_query' => array(
               'relation' => 'AND',
                array(
                   'key' => em_append_meta_key('user'), 
                   'value' => $user_id, 
                   'compare' => '=', 
                   'type' => 'NUMERIC,'
                ),
                array(
                   'key' => em_append_meta_key('event'), 
                   'value' => $event_id, 
                   'compare' => '=', 
                   'type' => 'NUMERIC,' 
                ),
            ),
            'post_type' => $this->post_type
        );
        return $this->get_all($args);
    }

    public function event_count_by_organizer( $organizer_id ) {
        return count( $this->events_by_organizer( $organizer_id ) );
    }
    public function events_by_organizer( $organizer_id ) {
        $args = array(
            'post_status' => 'any',
            'posts_per_page' => -1,
            'post_type' => EM_EVENT_POST_TYPE,
            'meta_key' => em_append_meta_key('start_date'),
            'orderby' => 'meta_value_num',
            'order' => 'ASC',
            'meta_query' => array(
                array(
                    'key'     => 'em_organizer',
                    'value'   => sprintf(':%s;', $organizer_id),
                    'compare' => 'LIKE'
                )
            )
        );
        $events = get_posts($args);
        return $events;
    }
}