<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class EventM_Event_Type_DAO extends EventM_Term_Dao
{   
    public function __construct() {
        parent::__construct(EM_EVENT_TYPE_TAX);
    }

    public function get($id) { 
        $term= $this->get_single($id);
        if (empty($term) || is_wp_error($term))
            return new EventM_Event_Type_Model(0);

        $type = new EventM_Event_Type_Model($id);
        $meta= $this->get_meta($id,'',true);
        if(is_array($meta)){
            foreach ($meta as $key=>$val) {
                $key= str_replace('em_','',$key);
                if (property_exists($type, $key)) {
                   $type->{$key}= maybe_unserialize($val[0]);
                }
            }
        }
        
        $type->id= $term->term_id;
        $type->name=htmlspecialchars_decode($term->name);
        $type->count= $term->count;
        return $type;
    }
    
   public function get_all($args= array()) {
        $defaults= array('hide_empty' => false);
        $args = wp_parse_args($args,$defaults);
        $terms=parent::get_all($args);
        $types= array();
        if(empty($terms) || is_wp_error($terms)){
           return $types;
        }
        foreach($terms as $term){
           $types[]= $this->get($term->term_id);
        }
        return $types;
    }
    
    public function save($model){
        $term= parent::save($model);
        if ($term instanceof WP_Error) {
            return false;
        }
        return $this->get($term['term_id']);
    }
    
}
