<?php

class EventM_Event_Organizer_Model extends EventM_Array_Model
{
    public $id;
    public $name;
    public $organizer_phones=array();
    public $organizer_emails=array();
    public $organizer_websites=array();
    public $image_id;
    public $description;
}
