<?php

interface EventM_Base_Model {
    public function load_attributes();
}
