<?php

if (!defined('ABSPATH')) {
    exit;
}

class EventM_User_Service {

    private $dao;
    private static $instance = null;
    
    private function __construct() {}
    
    public static function get_instance()
    {   
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function register_user() {
        $user_data = new stdClass();
        $response = new stdClass();
        $user_data->email = sanitize_email(event_m_get_param("email", true));
        $user_data->password = sanitize_text_field(event_m_get_param("password", true));
        $recaptcha_enabled = sanitize_text_field(event_m_get_param("recaptcha_enabled", true));
        if( !empty($recaptcha_enabled) && $recaptcha_enabled == 1 ){
            $user_data->captchaResponse = sanitize_text_field(event_m_get_param("captchaResponse", true));
            if (empty($user_data->captchaResponse)) {
                wp_send_json_error(array('captcha_msg' => __('Please check google recaptcha box.', 'eventprime-event-calendar-management')));
            }
            $result = $this->verify_captcha($user_data->captchaResponse);
            if (empty($result['success'])) {
                wp_send_json_error(array('captcha_msg' => __('Invalid google recaptcha response.', 'eventprime-event-calendar-management')));
            }
        }
        if (!$this->verify_user($user_data->email)) {
            $user_id = wp_create_user($user_data->email, $user_data->password, $user_data->email);
            if (!is_wp_error($user_id)) {
                $this->add_user_meta($user_id);
                do_action('event_magic_after_user_registration', $user_id);
                $user_data->user_id = $user_id;
                EventM_Notification_Service::user_registration($user_data);
                wp_send_json_success();
            } else {
                wp_send_json_error(array('msg' => $user_id->get_error_message()));
            }
        }
        wp_send_json_error(array('msg' => __('User already exists.', 'eventprime-event-calendar-management')));   
        
    }

    public function verify_user($email) {
        // Assuming both email and username are same
        return (username_exists($email) || email_exists($email));
    }

    private function add_user_meta($user_id) {
        $user = get_user_by('ID', $user_id);
        if ($user) {
            update_user_meta($user_id, 'first_name', event_m_get_param('first_name', true));
            update_user_meta($user_id, 'last_name', event_m_get_param('last_name', true));
            update_user_meta($user_id, 'phone', event_m_get_param('phone', true));
            do_action('event_magic_add_user_custom_meta', $user_id);
        }
    }

    public function login_user() {
        $user_name = event_m_get_param("user_name", true);
        $password = event_m_get_param("password", true);
        $response = new stdClass();
        $user_id = 0;
        $is_disabled = 1;
        // Check if user exists
        if (username_exists($user_name)) {
            $user = get_user_by('login', $user_name);
            $user_id = $user->ID;
        } elseif (email_exists($user_name)) {
            $user = get_user_by('email', $user_name);
            $user_id = $user->ID;
        } elseif ($user_name == "") {
            $error = new WP_Error('user_not_exists', __('Username cannot be blank.', 'eventprime-event-calendar-management'));
            echo json_encode($error);
            die;
        } elseif ($password == "") {
            $error = new WP_Error('user_not_exists', __('Password cannot be blank.', 'eventprime-event-calendar-management'));
            echo json_encode($error);
            die;
        } else {
            $error = new WP_Error('user_not_exists', __('User does not exists. Please check your details.', 'eventprime-event-calendar-management'));
            echo json_encode($error);
            die;
        }
        $is_disabled = (int) get_user_meta($user_id, 'rm_user_status', true);
        if ($is_disabled) {
            $error = new WP_Error('user_not_exists', __('User is not active yet.', 'eventprime-event-calendar-management'));
            echo json_encode($error);
            die;
        }
        $info['user_login'] = $user->user_login;
        $info['user_password'] = event_m_get_param("password");
        $info['remember'] = true;
        $user_signon = wp_signon($info, false);
        if (is_wp_error($user_signon)) {
            $error = new WP_Error('invalid_user', __('Wrong Username/Email or Password.', 'eventprime-event-calendar-management'));
            echo json_encode($error);
            die;
        } else {
            wp_set_current_user($user_signon->ID);
            $response->success = true;
            $response->redirect = '';
            $url_event_id = event_m_get_param("event_id", true);
            if(!empty($url_event_id)){
                $events_page = em_global_settings('events_page');
                $link_href = add_query_arg("event", $url_event_id, get_permalink($events_page));
                if(!empty($link_href)){
                    // check for event custom link
                    $service = EventM_Factory::get_service('EventM_Service');
                    $event = $service->load_model_from_db($url_event_id);
                    if(absint($event->custom_link_enabled) == 1){
                        $response->redirect = $event->custom_link;
                    }
                    else{
                        $response->redirect = $link_href;
                    }
                }
            }
            echo json_encode($response);
            die;
        }
        die();
    }
    
    public function verify_captcha($userResponse) {
        $settings_service= EventM_Factory::get_service('EventM_Setting_Service');
        $gs = $settings_service->load_model_from_db();
        $fields_string = '';
        $fields = array();
        $fields['secret'] = $gs->google_recaptcha_secret_key;
        $fields['response'] = $userResponse;
          
        foreach($fields as $key=>$value)
        $fields_string .= $key . '=' . $value . '&';
        $fields_string = rtrim($fields_string, '&');

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, True);

        $res = curl_exec($ch);
        curl_close($ch);

        return json_decode($res, true);
    }
}