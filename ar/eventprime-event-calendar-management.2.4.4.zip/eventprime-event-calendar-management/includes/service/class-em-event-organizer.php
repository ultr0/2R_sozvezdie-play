<?php

if (!defined('ABSPATH')) {
    exit;
}

class EventOrganizerM_Service {

    private $dao;
    private static $instance = null;
    
    private function __construct() {
        $this->dao = new EventM_Event_Organizer_DAO();
    }
    
    public static function get_instance()
    {   
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /*
     * Load Add/Edit page for REST 
     */
    public function load_edit_page() {
        $id = event_m_get_param('term_id');
        $event_organizer = $this->load_model_from_db($id);
        $event_organizer->image = $this->get_image($event_organizer->image_id);
        return $event_organizer;
    }

    /*
     * Load List page for REST 
     */

    public function load_list_page() {
        $response = new stdClass();
        $response->terms = array();
        $sort_option = event_m_get_param('sort_option');
        $args = array('hide_empty' => false,
            'offset' =>(absint(event_m_get_param('paged')) - 1) * EM_PAGINATION_LIMIT,
            'number' => EM_PAGINATION_LIMIT, 
            'orderby' => $sort_option, 
            'order' =>  event_m_get_param('order')
        );
        $response->terms = $this->get_organizers($args);
        $terms_count = wp_count_terms(EM_EVENT_ORGANIZER_TAX, array('hide_empty' => false));
        if ($terms_count > 0){
            $response->total_count = range(1, $terms_count);
        }
        $response->pagination_limit = EM_PAGINATION_LIMIT;
        $response->tax_type = EM_EVENT_ORGANIZER_TAX;
        // Loading default sorting options
        $response->sort_options = em_array_to_options(
            array(
                "count" => __('No. of events', 'eventprime-event-calendar-management'),
                "name"  => __('Alphabetically', 'eventprime-event-calendar-management')
            )
        );
        $response->sort_option = $sort_option;
        return $response;
    }

    /*
     * Saving Event Type (Term) 
     */
    public function save($model) {

        // Check if user added any image
        $image_id = isset($model->image_id) ? $model->image_id : '';
        if (!empty($image_id)) {
            $model->image_id = $image_id;
        }
        $organizer = $this->dao->save($model);
        return $organizer;
    }

    public function load_model_from_db($id) {
        return $this->dao->get($id);
    }

    public function map_request_to_model($id, $model = null) {
        $type = new EventM_Event_Organizer_Model($id);
        $data = (array) $model;

        if (!empty($data) && is_array($data)) {
            foreach ($data as $key => $val) {
                if(property_exists($type, $key)){
                    $type->{$key}= $val;
                }
            }
        }
        return $type;
    }

    public function validate($model) {
        $errors= array();
        $term = term_exists($model->name, EM_EVENT_ORGANIZER_TAX);
        if (!empty($term) && isset($term['term_id']) && $term['term_id'] != $model->id) {
            $errors[]= __('Please use different name.','eventprime-event-calendar-management');
        }
        foreach($model->organizer_emails as $email) {
            if (!preg_match('/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/',$email)) {
                $errors[]=__('Incorrect email format.','eventprime-event-calendar-management');
                break;
            }
        }

        foreach($model->organizer_websites as $website) {
            if (!preg_match('/^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/',$website)) {
                $errors[]=__('Incorrect website URL format.','eventprime-event-calendar-management');
                break;
            }
        }
        return $errors;
    }

    public function count($args) {
        $types = $this->dao->get_all($args);
        return count($types);
    }

    public function get_organizers($args = array()) {
        $types = $this->dao->get_all($args);
        return $types;
    }
    
    public function get_image($id, $size='thumbnail') {
       $img = wp_get_attachment_image_src($id, $size);
       if (!empty($img))
         return $img[0];
       return null;
    }

    public function get_organizer($term_id) {
        $term_id = absint($term_id);
        if (empty($term_id))
            return 0;

        return $this->dao->get($term_id);
    }

    /*
     * Load List page for Search result 
     */

    public function load_list_page_with_search() {
        $response = new stdClass();
        $response->terms = array();
        $sort_option = event_m_get_param('sort_option');
        $searchKeyword = !empty(event_m_get_param('searchKeyword')) ? event_m_get_param('searchKeyword') : '';
        $terms_count = wp_count_terms(EM_EVENT_ORGANIZER_TAX, array('hide_empty' => false, 'name__like' => $searchKeyword));
        if($terms_count <= 10){
           $pagedS = 1;
        }else{
            $pagedS = event_m_get_param('pagedS');
        }
        $args= array('hide_empty' => false,
            'offset'     =>(absint($pagedS) - 1) * EM_PAGINATION_LIMIT,
            'number'     => EM_PAGINATION_LIMIT, 
            //'orderby'    => 'term_id',
            'orderby'    =>  $sort_option,
            'order'      => 'DESC', 
            'name__like' => $searchKeyword);
        $response->terms = $this->get_organizers($args);
        if ($terms_count > 0){
            $response->total_count = range(1, $terms_count);
        }
        $response->pagination_limit = EM_PAGINATION_LIMIT;
        $response->tax_type = EM_EVENT_ORGANIZER_TAX;
        $response->sort_options = em_array_to_options(
            array(
                "count" => __('No. of events', 'eventprime-event-calendar-management'),
                "name" => __('Alphabetically', 'eventprime-event-calendar-management')
            )
        );
        $response->sort_option = $sort_option;
        $response->searchedKeyword = $searchKeyword;
        return $response;
    }

}?>