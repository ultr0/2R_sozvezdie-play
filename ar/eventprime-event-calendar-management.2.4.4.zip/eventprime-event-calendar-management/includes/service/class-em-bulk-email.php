<?php

if (!defined('ABSPATH')) {
    exit;
}

class EventM_Bulk_Emails_Service {

    private $dao;
    private static $instance = null;
    
    private function __construct() {}
    
    public static function get_instance()
    {   
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function load_new_emails_page() {
        $data= new stdClass();
        $filter = array();
        $filter = array(
            'numberposts' => -1,
            'post_status' => 'publish',
            'order' => 'DESC',
            'post_type' => EM_EVENT_POST_TYPE,
            'meta_query' => array(
                array(
                    'key' => em_append_meta_key( 'enable_booking' ),
                    'value' => 1,
                    'compare' => '=',
                    'type' => 'NUMERIC,'
                ),
            ),
        );
        $event_service = EventM_Factory::get_service('EventM_Service');
        $events = $event_service->get_events($filter);
        $data->events = array();
        //$data->events[] = array( 'id' => 0, 'title' => esc_html__( 'Select Events', 'eventprime-event-calendar-management' ) );
        if (!empty($events)) {
            foreach ($events as $event) {
                $tmp = new stdClass();
                $tmp->id = $event->ID;
                if ($event->post_parent > 0) {
                    $date = em_showDateTime( $event_service->get_meta( $event->ID, 'start_date' ), false, "m/d/Y" );
                    $tmp->title = $event->post_title . ' - ' . $date;
                } else {
                    $tmp->title = $event->post_title;
                }
                $data->events[] = $tmp;
            }
        }
        
        return $data;
    }

    public function send_bulk_emails() {
        $email_address = event_m_get_param( 'email_address' );
        $email_subject = event_m_get_param( 'email_subject' );
        $content = event_m_get_param( 'content' );
        $event_id = event_m_get_param( 'event_id' );
        if( empty( $email_address ) ) {
            $error_msg = esc_html__( 'Please enter email address', 'eventprime-event-calendar-management' );
            return array( "error" => 1, "message" => $error_msg );
        }
        if( empty( $email_subject ) ) {
            $error_msg = esc_html__( 'Subject is a required field', 'eventprime-event-calendar-management' );
            return array( "error" => 1, "message" => $error_msg );
        }
        if( empty( $content ) ) {
            $error_msg = esc_html__( 'Email content is a required field', 'eventprime-event-calendar-management' );
            return array( "error" => 1, "message" => $error_msg );
        }
        $email_address = explode( ',', $email_address );
        if( count( $email_address ) > 0 ) {
            foreach( $email_address as $email ){
                if ( !filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
                    $error_msg = esc_html__( $email. ' is not a valid email', 'eventprime-event-calendar-management' );
                    return array( "error" => 1, "message" => $error_msg );
                }
            }

            foreach( $email_address as $email ) {
                wp_mail( $email, $email_subject, $content);
            }
        }
        wp_send_json_success( array( 'success' => 1, "message" => esc_html__( 'Email send successfully', 'eventprime-event-calendar-management' ) ) );
    }
}