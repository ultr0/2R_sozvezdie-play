<?php
    $gs_service = EventM_Factory::get_service('EventM_Setting_Service');
    $gs_model = $gs_service->load_model_from_db();
    $frontend_page_link = get_page_link($gs_model->performers_page);
?>
<?php do_action('event_magic_admin_promotion_banner'); ?>
<div class="kikfyre" ng-app="eventMagicApp" ng-controller="performerCtrl" ng-init="initialize('list')" ng-cloak>
    <div class="kf_progress_screen" ng-show="requestInProgress"></div>
    <div class="kf-hidden" style="{{requestInProgress ?'display:none':'display:block'}}">
    <div class="kf-operationsbar dbfl">
         <div class="kf-title difl">
        <?php $manager_navs= em_manager_navs(); ?>
            <select class="kf-dropdown" onchange="em_manager_nav_changed(this.value)">
                <?php foreach($manager_navs as $nav): ?>
                <option <?php echo $nav['key']=='em_performers' ? 'selected' : ''; ?> value="<?php echo $nav['key']; ?>"><?php echo $nav['label']; ?></option>
                <?php endforeach; ?>
            </select>
         </div>
        <div class="difr ep-support-links"><a target="__blank" href="https://eventprime.net/contact/"><?php _e('Submit Support Ticket', 'eventprime-event-calendar-management'); ?></a></div>
        <div class="difr ep-support-links"><a target="__blank" href="<?php echo $frontend_page_link; ?>"><?php _e('Frontend', 'eventprime-event-calendar-management'); ?></a></div>
        <div class="kf-nav dbfl">
            <ul>
                <li><a ng-href="<?php echo admin_url('/admin.php?page=em_performers&tab=add'); ?>"><?php _e('Add New','eventprime-event-calendar-management'); ?></a></li>
                <li><button class="em_action_bar_button" ng-click="deletePosts()" ng-disabled="selections.length == 0" ><?php _e('Delete','eventprime-event-calendar-management'); ?></button></li>
                <li> <input type="checkbox" ng-model="selectedAll" ng-click="checkAll()"  ng-checked="selections.length == data.posts.length"id="select_all"/><label for="select_all"><?php _e('Select All','eventprime-event-calendar-management'); ?></label></li>
                <li><a target="_blank" href="https://eventprime.net/how-add-performers-wordpress-events/"><?php _e('Performers Guide','eventprime-event-calendar-management'); ?> <span class="dashicons dashicons-book-alt"></span></a></li>
                <li class="kf-toggle difr"><?php _e('Sort By', 'eventprime-event-calendar-management'); ?>
                    <select class="kf-dropdown" ng-change="preparePerformerListPage(sort_option)" ng-options="sort_option.key as sort_option.label for sort_option in data.sort_options" ng-model="data.sort_option">
                    </select>                                 
                </li>
            </ul>
        </div>

    </div>
    
    <div class="kf-cards emagic-performers dbfl">

        <div class="kf-card difl" ng-repeat="post in data.posts">
            
             <div ng-if="post.cover_image_url" class="kf_cover_image dbfl"><img ng-show="post.cover_image_url" ng-src="{{post.cover_image_url}}" /></div>
             <div ng-if="!post.cover_image_url" class="kf_cover_image dbfl"><img ng-src="<?php echo esc_url(plugins_url('/images/event_dummy.png', __FILE__)) ?>" /></div>
           <div class="kf-card-content dbfl">
               <div class="kf-card-title dbfl kf-wrap"><input type="checkbox" ng-model="post.Selected" ng-click="selectPost(post.id)"  ng-true-value="{{post.id}}" ng-false-value="0" id="{{post.name}}"><label for="{{post.name}}">{{post.name}}</label></div>
               <div class="dbfl">
            <div class="kf-per-role"> 
                    {{post.role}}
            </div>
            <div class="kf_upcoming dbfl"> 
                <?php _e('Event(s)', 'eventprime-event-calendar-management'); ?> <span class="kf_upcoming_count">{{post.events}}</span>
            </div>
               </div>
            <div class="em_venue_name kf_performer_descp kf-wrap dbfl">
                {{post.short_description}}  
            </div>
               
               <div class="ep-performer-shortcode dbfl">[em_performer id="{{post.id}}"]</div>
           
                <div class="kf-card-info ep-edit-performer dbfl"><a ng-href="<?php echo admin_url('/admin.php?page=em_performers&tab=add'); ?>&post_id={{post.id}}"><?php _e('Edit','eventprime-event-calendar-management'); ?></a></div>

            </div>
        </div>
        
        <div class="em_empty_card" ng-show="data.posts.length==0">
            <?php _e('The Performer you create will appear here as neat looking Performer Cards. Presently, you do not have any performer created.','eventprime-event-calendar-management'); ?>
        </div>

    </div>
    
    <div class="kf-pagination dbfr" ng-show="data.posts.length!==0"> 
        <ul>
             <li class="difl" dir-paginate="post in data.total_posts | itemsPerPage: data.pagination_limit"></li>
        </ul>
         <dir-pagination-controls on-page-change="pageChanged(newPageNumber)"></dir-pagination-controls>
    </div>
    </div>
</div>



