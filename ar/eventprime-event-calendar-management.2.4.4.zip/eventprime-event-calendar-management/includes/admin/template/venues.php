<?php
    $gs_service = EventM_Factory::get_service('EventM_Setting_Service');
    $gs_model = $gs_service->load_model_from_db();
    $frontend_page_link = get_page_link($gs_model->venues_page);
?>
<?php do_action('event_magic_admin_promotion_banner'); ?>
<div class="kikfyre" ng-app="eventMagicApp" ng-controller="venueCtrl" ng-init="initialize('list')" ng-cloak>
    <div class="kf_progress_screen" ng-show="requestInProgress"></div>  
    <div class="kf-hidden" style="{{requestInProgress ?'display:none':'display:block'}}">
        <div class="kf-operationsbar dbfl">
            <div class="kf-title difl">
                <?php $manager_navs = em_manager_navs(); ?>
                <select class="kf-dropdown test" onchange="em_manager_nav_changed(this.value)">
                    <?php foreach ($manager_navs as $nav): ?>
                        <option <?php echo $nav['key'] == 'em_venues' ? 'selected' : ''; ?> value="<?php echo $nav['key']; ?>"><?php echo $nav['label']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="difr ep-support-links"><a target="__blank" href="https://eventprime.net/contact/"><?php _e('Submit Support Ticket', 'eventprime-event-calendar-management'); ?></a></div>
            <div class="difr ep-support-links"><a target="__blank" href="<?php echo $frontend_page_link; ?>"><?php _e('Frontend', 'eventprime-event-calendar-management'); ?></a></div>
            <div class="kf-icons difl">
            </div>
            <div class="kf-nav dbfl">
                <ul class="dbfl">
                    <li><a href="?page=em_venue_add"><?php _e('Add New', 'eventprime-event-calendar-management'); ?></a></li>
                    <li><button class="em_action_bar_button" ng-click="deleteTerms()" ng-disabled="selections.length == 0" ><?php _e('Delete', 'eventprime-event-calendar-management'); ?></button></li>
                    <li> <input type="checkbox" ng-model="selectedAll" ng-click="checkAllVENUES()" ng-checked="selections.length == data.terms.length" id="select_all"/>
                        <label for="select_all"><?php _e('Select All', 'eventprime-event-calendar-management'); ?></label>
                    </li>
                    <li><a target="_blank" href="https://eventprime.net/how-showcase-event-location-details-event-sites/"><?php _e('Event Sites Guide','eventprime-event-calendar-management'); ?> <span class="dashicons dashicons-book-alt"></span></a></li>
                    <li class="kf-toggle difr"><?php _e('Sort By', 'eventprime-event-calendar-management'); ?>
                        <select class="kf-dropdown" ng-change="prepareVenueListPage(sort_option)" ng-options="sort_option.key as sort_option.label for sort_option in data.sort_options" ng-model="data.sort_option">
                        </select>                                 
                    </li>


                </ul>
            </div>

        </div>

        <div class="kf-cards emagic-venue-cards dbfl">

            <div class="kf-card difl" ng-repeat="term in data.terms">
                <div ng-if="term.feature_image" class="kf_cover_image dbfl"><img ng-show="term.feature_image" ng-src="{{term.feature_image}}" /></div>
                <div ng-if="!term.feature_image" class="kf_cover_image dbfl"><img ng-src="<?php echo esc_url(plugins_url('/images/event_dummy.png', __FILE__)) ?>" /></div>
                <div class="kf-card-content dbfl">
                    <div class="kf-card-title kf-wrap dbfl" title="{{term.name}}"><input type="checkbox"  ng-model="term.Selected" ng-click="selectTerm(term.id)"  ng-true-value="{{term.id}}" ng-false-value="0" id="{{term.name}}"><label for="{{term.name}}">{{term.name}}</label></div>

                    <div class="kf_upcoming dbfl">  
                        <?php _e('Event(s)', 'eventprime-event-calendar-management'); ?> <span class="kf_upcoming_count">{{term.event_count}}</span>
                    </div>
                    <div class="kf_venue_seats kf-wrap dbfl" ng-show="term.type == 'standings'">  
                        <span class="kf_upcoming_count">{{term.standing_capacity}} <?php _e('Standing Capacity', 'eventprime-event-calendar-management'); ?></span>
                    </div>
                    <?php
                    $em = event_magic_instance();
                    if (in_array('seating', $em->extensions)):
                        ?>
                        <div class="kf_venue_seats kf-wrap dbfl" ng-show="term.type=='seats'">  
                            <span class="kf_upcoming_count" ng-show="term.seating_capacity != null">{{term.seating_capacity}} <?php _e('Seats', 'eventprime-event-calendar-management'); ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="em_venue_address kf-wrap dbfl" title="{{term.address}}">  
                        {{term.address}}
                    </div>

                    <div class="ep-eventsite-shortcode dbfl">[em_event_site id="{{term.id}}"]</div>

                    <div class="ep-edit-eventsite  dbfl"><a ng-href="<?php echo admin_url('/admin.php?page=em_venue_add'); ?>&term_id={{term.id}}"><?php _e('Edit Site', 'eventprime-event-calendar-management'); ?></a></div>


                </div>

            </div>

            <div class="em_empty_card difl ep-info-notice epnotice" ng-show="data.terms.length == 0">
                <?php _e('The Event Site you create will appear here as neat looking Event Site Cards. Presently, you do not have any Event Site created.', 'eventprime-event-calendar-management'); ?>
            </div>
        </div>


        <div class="kf-pagination dbfr" ng-show="data.terms.length != 0"> 
            <ul class="empagination">
                <li class="difl" dir-paginate="term in data.total_count | itemsPerPage: data.pagination_limit"></li>
            </ul>
            <dir-pagination-controls on-page-change="pageChanged(newPageNumber)"></dir-pagination-controls>
        </div>
    </div>

</div>



