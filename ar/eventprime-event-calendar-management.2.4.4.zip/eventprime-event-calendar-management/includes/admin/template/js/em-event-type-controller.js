/************************************* EventType Controller ***********************************/

eventMagicApp.controller('eventTypeCtrl',function($scope, $http, TermUtility, EMRequest, MediaUploader){
    $scope.data={};
    $scope.requestInProgress= false;
    $scope.formErrors=[];
    $scope.selections = [];
    $scope.paged=1;
    $=jQuery;
    
    /* Show/Hide element while performing HTTP request */
    $scope.progressStart= function()
    {
        $scope.requestInProgress = true;
    }
    
    $scope.progressStop= function()
    {
        $scope.requestInProgress = false;
    }
    
    /*
     * Setting background color
    */
    $scope.bgColor= function(term)
    {   
        var style= {"background-color": "#" + term.color};
        return style;
    }

    $scope.textColor= function(term)
    {   
        var style= {"background-color": "#" + term.type_text_color};
        return style;
    }
    
    /*
     * Loading Event type page data
     */
    $scope.preparePageData = function () {
        $scope.data.em_request_context= 'admin_event_type';
        $scope.data.term_id= em_get('term_id');
        $scope.progressStart();
        EMRequest.send('em_load_strings',$scope.data).then(function(response){
            $scope.progressStop();
            var responseBody= response.data;
            if(!responseBody.success)
                return;
            $scope.data= responseBody.data;
            if($scope.data.term.color)
                $("#em_color_picker").css("background-color","#" + $scope.data.term.color);

            if($scope.data.term.type_text_color)
                $("#em_text_color_picker").css("background-color","#" + $scope.data.term.type_text_color);
            $scope.setupSlider();
         });
    };
    
    /*
     * 
     * WordPress default media uploader to choose image
     */
    $scope.mediaUploader = function (multiImage) {
        var mediaUploader = MediaUploader.openUploader(multiImage);
        // When a file is selected, grab the URL and set it as the text field's value
        mediaUploader.on('select', function () {
            attachments = mediaUploader.state().get('selection');
            attachments.map(function (attachment) {
                attachment = attachment.toJSON();
                if (!multiImage) {
                    // Event Type Image
                    $scope.data.term.image = attachment.sizes.thumbnail === undefined ? attachment.sizes.full.url : attachment.sizes.thumbnail.url;
                    $scope.data.term.image_id = attachment.id;
                    $scope.$apply();
                }
            });
        });
        // Open the uploader dialog
        mediaUploader.open();
    }
    
    $scope.setupSlider= function(){
        var ranges= [21,28];
        if($scope.data.term.custom_group){
            if($scope.data.term.custom_group.indexOf("-")>=0){
                rangeArr= $scope.data.term.custom_group.split("-");
                ranges[0]=rangeArr[0];
                ranges[1]= rangeArr[1];
            }
        }
        
        if($scope.data.term.custom_group==null){
            $scope.data.term.custom_group=ranges[0]+ "-" + ranges[1];
        }
        $("#slider").slider({		
          create: function() {		
            $(this).slider(		
                    {	
                     range: true,
                     min: 0,		
                     max: 100,
                     values: ranges,
                     slide: function(event,ui){
                             $scope.data.term.custom_group=ui.values[0]+ "-" + ui.values[1]; 
                             $scope.$apply();
                     },
                 });		
          }		
        });		
    }
     
     /*
     * Save information
     */
    $scope.saveEventType = function (isValid) {
         // Return if form invalid
         if (!isValid)
             return;
         $scope.formErrors= [];
         if( $('#description').is(':visible') ) 
            $scope.data.term.description= $('#description').val();
         else 
            $scope.data.term.description= tinymce.get('description').getContent();   
            
         $scope.progressStart();
         EMRequest.send('em_save_event_type',$scope.data.term).then(function(response){
            $scope.progressStop();
            var responseBody= response.data;
            if(responseBody.success){
                if(responseBody.data.hasOwnProperty('redirect')){
                    location.href=responseBody.data.redirect;
                }
            }
            else
            {
                if(responseBody.data.hasOwnProperty('errors')){
                    $scope.formErrors= responseBody.data.errors;
                    $('html, body').animate({ scrollTop: 0 }, 'slow');
                }
            }
        });
    }
    
    /*
     * Initializa page data on init
     */
    $scope.initialize= function(type){

        if(type=="edit")
            $scope.preparePageData();
        
        if(type=="list")  
            $scope.prepareListPage();   
    }
    
    /*
     * Fetch list page data
     */
    $scope.prepareListPage= function(){ 
        $scope.request_in_progress= true;
        $scope.data.em_request_context='admin_event_types';
        $scope.data.paged= $scope.paged;
        $scope.progressStart();
        EMRequest.send('em_load_strings',$scope.data).then(function(response){
            $scope.progressStop();
            var responseBody= response.data;
            if(!responseBody.success)
                return;
            $scope.data= responseBody.data;
            $scope.request_in_progress= false;
        });
    }
    
    /*
     * Select item
     */
    $scope.selectTerm= function(term_id){
        if($scope.selections.indexOf(term_id)>=0)
           $scope.selections= em_remove_from_array($scope.selections,term_id);
        else
            $scope.selections.push(term_id);
    }
    
    /*
     * Called when pagination changeds
     */
    $scope.pageChanged= function(pageNumber){
       
        $scope.paged= pageNumber;
        $scope.prepareListPage();
         $scope.selectedAll=false;
    }
    
    /*
     * Request for Event Type deletion
     */
    $scope.deleteTerms= function(){
        var confirmed= confirm("All Events associated to Event-Type(s) will be deleted. Please confirm");
        if(confirmed){
           $scope.progressStart();
           TermUtility.delete($scope.selections,$scope.data.tax_type).then(function(data) {
               location.reload();
            });
        }
       
    }
    
    /*
     * Selection in bulk
     */
    $scope.checkAll = function () { 
//        if ($scope.selectedAll)         
//            $scope.selectedAll = true;
//        else 
//            $scope.selectedAll = false;   
//        
//        angular.forEach($scope.data.terms, function (term) {
//               $scope.selections.push(term.id);
//               term.Selected = $scope.selectedAll ? term.id : 0; 
//        });
//    };
    
     angular.forEach($scope.data.terms, function (term) {
               if ($scope.selectedAll) { 
                 $scope.selections.push(term.id);
               // console.log($scope.selections.push(post.id));
                  term.Selected = $scope.selectedAll ? term.id : 0; 
                   }
                   else{
                        $scope.selections= [];
                        term.Selected = 0;
                   }
            });
    };
});