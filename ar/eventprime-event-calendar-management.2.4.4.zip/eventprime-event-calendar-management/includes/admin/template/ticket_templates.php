<?php do_action('event_magic_admin_promotion_banner'); ?>
<div class="kikfyre ep-banner-container">
    <div class="kf-titlebar dbfl">
        <div class="kf-db-title dbfl"><?php _e('Ticket Manager', 'eventprime-event-calendar-management'); ?></div>
    </div>
    <div class="ep-ticket-ext dbfl"> <a href="https://eventprime.net/plans/" target="_blank"><img  class="ep-extension-bundle" alt="Event Ticketing & Seating" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-tickets-banner.png" ></a> </div>
</div>