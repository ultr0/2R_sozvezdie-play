<div class="kikfyre ep-banner-container">
    <div class="kf-titlebar dbfl">
        <div class="kf-title kf-title-1 difl"><?php _e('Analytics','eventprime-event-analytics'); ?></div>
    </div>
    <div class="ep-analytics-ext dbfl"> <a href="https://eventprime.net/extensions/event-analytics/" target="_blank"><img  class="ep-extension-bundle" alt="Event analytics" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-analytics-banner.png" ></a> </div>
    
    
</div>