<?php do_action('event_magic_admin_promotion_banner'); ?>
<div class="kikfyre kf-container"  ng-controller="venueCtrl" ng-app="eventMagicApp" ng-init="initialize('edit')" ng-cloak>
    <div class="kf_progress_screen" ng-show="requestInProgress"></div>
    <div class="kf-db-content">
        <div class="kf-title">
            <?php _e('Event Site/Location', 'eventprime-event-calendar-management'); ?>
        </div>

        <div class="form_errors">
            <ul>
                <li class="emfield_error" ng-repeat="error in  formErrors">
                    <span>{{error}}</span>
                </li>
            </ul>  
        </div>

        <div class="em_notice">
            <div class="map_notice" ng-show="!data.term.map_configured">
                {{data.term.map_notice}}
            </div>
        </div>
        <!-- FORM -->
        <form name="termForm" ng-submit="saveTerm(termForm.$valid)" novalidate >

            <div class="emrow">
                <div class="emfield"><?php _e('Name', 'eventprime-event-calendar-management'); ?><sup>*</sup></div>
                <div class="eminput">
                    <input placeholder="" required type="text" name="name"  ng-model="data.term.name">
                    <div class="emfield_error">
                        <span ng-show="termForm.name.$error.required && !termForm.name.$pristine"><?php _e('This is a required field.', 'eventprime-event-calendar-management'); ?></span>
                    </div>
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Name of the Event Site. Should be unique.', 'eventprime-event-calendar-management'); ?>
                </div>
            </div>

            <div class="emrow" ng-show="term_edit" style="display:none;">
                <div class="emfield"><?php _e('Slug', 'eventprime-event-calendar-management'); ?><sup>*</sup></div>
                <div class="eminput">
                    <input ng-required="term_edit" type="text" name="slug"  ng-model="data.term.slug">
                    <div class="emfield_error">
                        <span ng-show="termForm.slug.$error.required && !termForm.slug.$pristine"><?php _e('This is a required field.', 'eventprime-event-calendar-management'); ?></span>
                    </div>
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Slug is the user friendly URL for the Venue. Example: /minnesotagrounds,/sydneyolympicpark, /millersstadium etc.', 'eventprime-event-calendar-management'); ?>
                </div>
            </div>

            <div class="emrow kf-bg-light">
                <div class="emfield emeditor"><?php _e('Description', 'eventprime-event-calendar-management'); ?></div>
                <div class="eminput emeditor">
                    <?php
                    $id = event_m_get_param('term_id');
                    $content = '';
                    if (!empty($id)) {

                        $term = get_term($id);
                        $content = em_get_term_meta($id, 'description', true);
                    }
                    wp_editor($content, 'description');
                    ?>
                    <div class="emfield_error">
                    </div>
                </div>
                <div class="emnote emeditor">
                    <?php _e('Details about the Event Site. Will be displayed on Event and Event Site page.', 'eventprime-event-calendar-management'); ?>
                </div>
            </div>

            <div class="emrow kf-bg-light">
                <div class="emfield emeditor"><?php _e('Address', 'eventprime-event-calendar-management'); ?></div>
                <div class="eminput emeditor">
                    <input id="em-pac-input" name="address" ng-model="data.term.address" ng-keydown="editingAddress=true" ng-keyup="editingAddress=false" class="em-map-controls" type="text">
                    <div id="map" ng-show="data.term.map_configured"></div>
                    <div id="type-selector" class="em-map-controls" style="display:none">
                        <input type="radio" name="type" id="changetype-all" checked="checked">
                        <label for="changetype-all"><?php _e('All', 'eventprime-event-calendar-management'); ?></label>

                        <input type="radio" name="type" id="changetype-establishment">
                        <label for="changetype-establishment"><?php _e('Establishments', 'eventprime-event-calendar-management'); ?></label>

                        <input type="radio" name="type" id="changetype-address">
                        <label for="changetype-address"><?php _e('Addresses', 'eventprime-event-calendar-management'); ?></label>

                        <input type="radio" name="type" id="changetype-geocode">
                        <label for="changetype-geocode"><?php _e('Geocodes', 'eventprime-event-calendar-management'); ?></label>
                    </div>
                </div>
                <div class="emnote emeditor" ng-show="data.term.map_configured"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Mark map location for the Event Site. This will be displayed on Event page.', 'eventprime-event-calendar-management'); ?>
                </div>
                
                <div class="emrow" ng-show="data.term.map_configured">
                    <div class="emfield"><?php _e('Latitude', 'eventprime-event-calendar-management'); ?></div>
                    <div class="eminput">
                        <input  type="text" name="lat"  ng-model="data.term.lat" id="em_venue_lat">
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Latitude', 'eventprime-event-calendar-management'); ?>
                    </div>
                </div>
                
                <div class="emrow" ng-show="data.term.map_configured">
                    <div class="emfield"><?php _e('Longitude', 'eventprime-event-calendar-management'); ?></div>
                    <div class="eminput">
                        <input  type="text" name="lng"  ng-model="data.term.lng" id="em_venue_long">
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Longitude', 'eventprime-event-calendar-management'); ?>
                    </div>
                </div>

                <div class="emrow" ng-show="data.term.map_configured">
                    <div class="emfield"><?php _e('Zoom Level', 'eventprime-event-calendar-management'); ?></div>
                    <div class="eminput">
                        <input type="number" string-to-number name="zoom_level" ng-model="data.term.zoom_level" id="em_venue_zoom_level">
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Zoom Level On Map', 'eventprime-event-calendar-management'); ?>
                    </div>
                </div>

                <div class="emrow" ng-show="data.term.map_configured">
                    <div class="emfield"><?php _e('Display Address', 'eventprime-event-calendar-management'); ?></div>
                    <div class="eminput">
                        <input type="checkbox" name="display_address_on_frontend" ng-model="data.term.display_address_on_frontend" id="em_venue_display_address" ng-true-value="1" ng-false-value="0">
                    </div>
                    <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <?php _e('Display Address On Frontend', 'eventprime-event-calendar-management'); ?>
                    </div>
                </div>
            </div>

            <div class="emrow">
                <div class="emfield"><?php _e('Established', 'eventprime-event-calendar-management'); ?></div>
                <div class="eminput">
                    <input readonly="readonly" type="text" name="established"  ng-model="data.term.established" id="established">
                    <input type="button" value="Reset" ng-click="data.term.established = ''" />
                    <div class="emfield_error">
                        <span ng-show="termForm.established.$error.pattern && !termForm.established.$pristine"></span>
                    </div>
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('When the Event Site opened for public.', 'eventprime-event-calendar-management'); ?>
                </div>
            </div>

            <div class="emrow">
                <div class="emfield"><?php _e('Seating Type', 'eventprime-event-calendar-management'); ?><sup>*</sup></div>
                <div class="eminput">
                    <select required name="type"  ng-model="data.term.type" ng-options="type.key as type.label for type in data.term.types"></select>
                    <div class="emfield_error">
                        <span ng-show="termForm.type.$error.required && !termForm.type.$pristine"><?php _e('This is a required field.', 'eventprime-event-calendar-management'); ?></span>
                    </div>
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Type of seating arrangement- Standing or Seating.', 'eventprime-event-calendar-management'); ?>
                </div>
            </div>

            <div class="emrow" ng-if="data.term.type=='standings'">
                <div class="emfield"><?php _e('Standing Capacity', 'eventprime-event-calendar-management'); ?><sup>*</sup></div>
                <div class="eminput">
                    <input type="number" name="standing_capacity" ng-model="data.term.standing_capacity" required min="1">
                    <div class="emfield_error">
                        <span ng-show="termForm.standing_capacity.$error.required && data.term.type=='standings'"><?php _e('This is a required field.', 'eventprime-event-calendar-management'); ?></span>
                        <span ng-show="termForm.standing_capacity.$error.number && data.term.type=='standings'"><?php _e('Only numeric value allowed.', 'eventprime-event-calendar-management'); ?></span>
                        <span ng-show="termForm.standing_capacity.$error.min && data.term.type=='standings'"><?php _e('Value should be greater than 0', 'eventprime-event-calendar-management'); ?></span>
                    </div>
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Maximum capacity of the venue or the maximum number of bookings you wish to allow.', 'eventprime-event-calendar-management'); ?>
                </div>
            </div>

            <div class="emrow">
                <div class="emfield"><?php _e('Operator', 'eventprime-event-calendar-management'); ?></div>
                <div class="eminput">
                    <input  type="text" name="seating_organizer"  ng-model="data.term.seating_organizer" ng-disabled="isSeatingDisabled">
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Event Site coordinator name or contact details.', 'eventprime-event-calendar-management'); ?>
                </div>
            </div>

            <div class="emrow">
                <div class="emfield"><?php _e('Facebook Page', 'eventprime-event-calendar-management'); ?></div>
                <div class="eminput">
                    <input class="kf-fb-field" ng-pattern="/(?:(?:http|https):\/\/)?(?:www.)?facebook.com\/?/" type="url" name="facebook_page"  ng-model="data.term.facebook_page">
                    <div class="emfield_error">
                        <span ng-show="termForm.facebook_page.$error.url && !termForm.facebook_page.$pristine"><?php _e('Invalid Facebook URL', 'eventprime-event-calendar-management'); ?></span>
                    </div>
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Facebook page URL of the Event Site, if available. Eg.:https://www.facebook.com/XYZ/', 'eventprime-event-calendar-management'); ?>
                </div>
            </div>

            <div class="emrow kf-bg-light">
                <div class="emfield emeditor"><?php _e('Site Gallery', 'eventprime-event-calendar-management'); ?></div>
                <div class="eminput emeditor">
                    <input id="media_upload" type="button" ng-click="mediaUploader(true)" class="button kf-upload" value="<?php _e('Upload', 'eventprime-event-calendar-management'); ?>" />
                    <div class="em_gallery_images">
                        <ul id="em_draggable" class="dbfl">
                            <li class="kf-db-image difl" ng-repeat="(key, value) in data.term.images" id="{{value.id}}">
                                <div><img class="difl" ng-src="{{value.src[0]}}" />
                                    <span><input class="em-remove_button" type="button" ng-click="deleteGalleryImage(value.id, key)" value="Remove"/></span> 
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="emnote emeditor">
                    <?php _e('Displays multiple images of the Event Site as gallery.', 'eventprime-event-calendar-management'); ?>
                </div>
            </div>




            <input class="hidden" type="text" name="gallery_images" ng-model="data.term.gallery_images" />


            <?php do_action('event_magic_venue_seatings', $term_id); ?>


            <div class="dbfl kf-buttonarea">
                <div class="em_cancel"><a class="kf-cancel" href="<?php echo admin_url('/admin.php?page=em_venues'); ?>">&#8592; &nbsp;<?php _e('Cancel', 'eventprime-event-calendar-management'); ?></a></div>
                <button type="submit" class="btn btn-primary" ng-disabled="termForm.$invalid || requestInProgress || editingAddress"><?php _e('Save', 'eventprime-event-calendar-management'); ?></button>
                <span class="kf-error" ng-show="termForm.$invalid && termForm.$dirty"><?php _e('Please fill all required fields.', 'eventprime-event-calendar-management'); ?></span>
            </div>

            <div class="dbfl kf-required-errors" ng-show="termForm.$invalid && termForm.$dirty">
                <h3><?php _e("Looks like you missed out filling some required fields (*). You will not be able to save until all required fields are filled in. Here’s what's missing", 'eventprime-event-calendar-management'); ?> -

                    <span ng-show="termForm.name.$error.required"><?php _e('Name', 'eventprime-event-calendar-management'); ?></span>

                    <span ng-show="termForm.type.$error.required"><?php _e('Seating Type', 'eventprime-event-calendar-management'); ?></span>

                    <span ng-show="termForm.seating_capacity.$error.required"><?php _e('Seating Capacity', 'eventprime-event-calendar-management'); ?></span>

                    <span ng-show="termForm.rows.$error.required"><?php _e('Rows', 'eventprime-event-calendar-management'); ?></span>

                    <span ng-show="termForm.columns.$error.required"><?php _e('Columns', 'eventprime-event-calendar-management'); ?></span>
                </h3>
            </div>
        </form>
        <div id="show_popup" ng-show = "IsVisible">

            <div class="pm-popup-mask"></div>    
            <div id="pm-change-password-dialog">
                <div class="pm-popup-container">
                    <div class="pm-popup-title pm-dbfl pm-bg-lt pm-pad10 pm-border-bt">
                    </div>
                </div>
            </div>
        </div>


    </div>
</div>