<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$buy_link = event_m_get_buy_link();
$em = event_magic_instance();
?>
<div class="eventprime ep-full-width">
    <div class="ep-expage-title"> <b>EventPrime</b> <span>Extensions</span> </div>
    
    <div class="ep-exts-bundle-banner dbfl"> <a href="<?php echo empty($buy_link) ? 'https://eventprime.net/plans/' : $buy_link; ?>" target="_blank"><img  class="ep-extension-bundle" alt="EventPrime Extension Bundle" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-extension-banner.png" ></a> </div>
    <div class="ep-ext-list">
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $live_seating = em_get_more_extension_data('Live Seating');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $live_seating['url'];?>" class=" open-plugin-details-modal" target="_blank">
                            Live Seating
                            <img  class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>seating-integration-icon.png" > 
                        </a>
                    </h3>
                </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li> 
                            <a class="install-now button <?php echo $live_seating['class_name'];?>" href="<?php echo $live_seating['url'];?>"><?php echo $live_seating['button'];?></a>
                        </li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Add live seat selection on your events and provide seat based tickets to your event attendees. Set a seating arrangement for all your Event Sites with specific rows, columns, and walking aisles using EventPrime's very own Event Site Seating Builder.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $event_analytics = em_get_more_extension_data('Event Analytics');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $event_analytics['url'];?>" class=" open-plugin-details-modal" target="_blank">
                            Event Analytics
                            <img  class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-analytics-icon.png" > 
                        </a>
                    </h3>
                </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li class="ep-free-extension-wrap"> 
                            <a class="ep-free-extension" href="<?php echo $event_analytics['url'];?>" target="_blank">Free</a>
                        </li>
                        <li> 
                            <a class="install-now button <?php echo $event_analytics['class_name'];?>" href="<?php echo $event_analytics['url'];?>"><?php echo $event_analytics['button'];?></a>
                        </li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Stay updated on all the Revenue and Bookings coming your way through EventPrime. The Event Analytics extension empowers you with data and graphs that you need to know how much your events are connecting with their audience.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $event_sponsors = em_get_more_extension_data('Event Sponsors');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $event_sponsors['url'];?>" class=" open-plugin-details-modal" target="_blank">
                            Event Sponsors
                            <img  class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-sponser-icon.png" > 
                        </a>
                    </h3>
                </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li> <a class="install-now button <?php echo $event_sponsors['class_name'];?>" href="<?php echo $event_sponsors['url'];?>"><?php echo $event_sponsors['button'];?></a> </li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Add Sponsor(s) to your events. Upload Sponsor logos and they will appear on the event page alongside all other details of the event.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
              <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $stripe_payments = em_get_more_extension_data('Stripe Payments');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $stripe_payments['url'];?>" class=" open-plugin-details-modal" target="_blank">
                            Stripe Payments
                            <img  class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-stripe-icon.png" > 
                        </a>
                    </h3>
                </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li>
                            <a class="install-now button <?php echo $stripe_payments['class_name'];?>" href="<?php echo $stripe_payments['url'];?>"><?php echo $stripe_payments['button'];?></a>
                        </li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Start accepting Event Booking payments using the Stripe Payment Gateway. By integrating Stripe with EventPrime, event attendees can now pay with their credit cards while you receive the payment in your Stripe account.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $offline_payments = em_get_more_extension_data('Offline Payments');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $offline_payments['url'];?>" class=" open-plugin-details-modal" target="_blank">
                            Offline Payments
                            <img  class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-offline-payment.png" > 
                        </a>
                    </h3>
                </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li> <a class="install-now button <?php echo $offline_payments['class_name'];?>" href="<?php echo $offline_payments['url'];?>"><?php echo $offline_payments['button'];?></a> </li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Don't want to use any online payment gateway to collect your event booking payments? Don't worry. With the Offline Payments extension, you can accept event bookings online while you collect booking payments from attendees offline.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $recurring_events = em_get_more_extension_data('Recurring Events');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $recurring_events['url'];?>" class=" open-plugin-details-modal" target="_blank">
                            Recurring Events
                            <img class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-recurring-events-icon.png"> 
                        </a>
                    </h3>
                </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li> <a class="install-now button <?php echo $recurring_events['class_name'];?>" href="<?php echo $recurring_events['url'];?>"><?php echo $recurring_events['button'];?></a> </li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Create events that recur by your specified numbers of days, weeks, months, or years. Make updates to all recurring events at once by updating the main event. Or make custom changes to individual recurring events, such as different performers, event sites, booking amount etc.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $attendees_list = em_get_more_extension_data('Attendees List');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $attendees_list['url'];?>" class="open-plugin-details-modal" target="_blank">
                            Attendees List
                            <img class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-attendees-list-icon.png"> 
                        </a>
                    </h3>
                </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li> <a class="install-now button <?php echo $attendees_list['class_name'];?>" href="<?php echo $attendees_list['url'];?>"><?php echo $attendees_list['button'];?></a> </li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Display names of your Event Attendees on the Event page. Or within the new Attendees List widget.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $coupon_codes = em_get_more_extension_data('Coupon Codes');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $coupon_codes['url'];?>" class="open-plugin-details-modal" target="_blank">
                            Coupon Codes
                            <img class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>coupon-code-extension-icon.png"> 
                        </a>
                    </h3>
                </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li>
                            <a class="install-now button <?php echo $coupon_codes['class_name'];?>" href="<?php echo $coupon_codes['url'];?>"><?php echo $coupon_codes['button'];?></a>
                        </li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Create and activate coupon codes for allowing Attendees for book for events at a discount. Set discount type and limits on coupon code usage, or deactivate at will.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $guest_bookings = em_get_more_extension_data('Guest Bookings');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $guest_bookings['url'];?>" class="open-plugin-details-modal" target="_blank">
                            Guest Bookings
                            <img class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>event-guest-booking-icon.png"> 
                        </a>
                    </h3>
                </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li>
                            <a class="install-now button <?php echo $guest_bookings['class_name'];?>" href="<?php echo $guest_bookings['url'];?>"><?php echo $guest_bookings['button'];?></a>
                        </li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Allow attendees to complete their event bookings without registering or logging in.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $event_list_widgets = em_get_more_extension_data('Event List Widgets');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $event_list_widgets['url'];?>" class="open-plugin-details-modal" target="_blank">
                            Event List Widgets
                            <img class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>event-more-widget-icon.png"> 
                        </a>
                    </h3> </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li><a class="install-now button <?php echo $event_list_widgets['class_name'];?>" href="<?php echo $event_list_widgets['url'];?>"><?php echo $event_list_widgets['button'];?></a></li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Add 3 new Event Listing widgets to your website. These are the Popular Events list, Featured Events list, and Related Events list widgets.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $admin_attendee_bookings = em_get_more_extension_data('Admin Attendee Bookings');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $admin_attendee_bookings['url'];?>" class="open-plugin-details-modal" target="_blank">
                            Admin Attendee Bookings
                            <img class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-manually-attendees-booking.png"> 
                        </a>
                    </h3> </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li><a class="install-now button <?php echo $admin_attendee_bookings['class_name'];?>" href="<?php echo $admin_attendee_bookings['url'];?>"><?php echo $admin_attendee_bookings['button'];?></a></li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Admins can now create custom attendee bookings from the backend EventPrime dashboard.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $event_wishlist = em_get_more_extension_data('Event Wishlist');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $event_wishlist['url'];?>" class="open-plugin-details-modal" target="_blank">
                            Event Wishlist
                            <img class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-save-events-icon.png"> 
                        </a>
                    </h3> </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li><a class="install-now button <?php echo $event_wishlist['class_name'];?>" href="<?php echo $event_wishlist['url'];?>"><?php echo $event_wishlist['button'];?></a></li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Users can now wishlist events that they would like to attend and can see the list of all their wishlisted events on their frontend profiles.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $event_comments = em_get_more_extension_data('Event Comments');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $event_comments['url'];?>" class="open-plugin-details-modal" target="_blank">
                            Event Comments
                            <img class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-event-comment-icon.png"> 
                        </a>
                    </h3> </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li><a class="install-now button <?php echo $event_comments['class_name'];?>" href="<?php echo $event_comments['url'];?>"><?php echo $event_comments['button'];?></a></li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Allow users to post comments on EventPrime events. Admins can manage these comments the same way as they manage WordPress comments.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $event_automatic_discounts = em_get_more_extension_data('Event Automatic Discounts');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $event_automatic_discounts['url'];?>" class="open-plugin-details-modal" target="_blank">
                            Event Automatic Discounts
                            <img class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>event-early-bird-discount-icon.png"> 
                        </a>
                    </h3> </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li><a class="install-now button <?php echo $event_automatic_discounts['class_name'];?>" href="<?php echo $event_automatic_discounts['url'];?>"><?php echo $event_automatic_discounts['button'];?></a></li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Automatically display discounts on an event for a user based on Admin rules. With Automatic Discount Extension, you can create and activate discounts by setting rules (eligibility criteria) to offer the eligible users a discount on bookings. The discounts are automatically applied to the bookings.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $google_events_import_export = em_get_more_extension_data('Google Events Import Export');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $google_events_import_export['url'];?>" class="open-plugin-details-modal" target="_blank">
                            Google Events Import Export
                            <img class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-google-ie.png"> 
                        </a>
                    </h3>
                </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li><a class="install-now button <?php echo $google_events_import_export['class_name'];?>" href="<?php echo $google_events_import_export['url'];?>"><?php echo $google_events_import_export['button'];?></a></li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Admin now import and export his Google Calendar events to and from EventPrime Calendar.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $events_import_export = em_get_more_extension_data('Events Import Export');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $events_import_export['url'];?>" class="open-plugin-details-modal" target="_blank">
                            Events Import Export
                            <img class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-file-import-export-icon.png"> 
                        </a>
                    </h3>
                </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li class="ep-free-extension-wrap"> 
                            <a class="ep-free-extension" href="<?php echo $events_import_export['url'];?>" target="_blank">Free</a>
                        </li>
                        <li><a class="install-now button <?php echo $events_import_export['class_name'];?>" href="<?php echo $events_import_export['url'];?>"><?php echo $events_import_export['button'];?></a></li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Import or export events in popular file formats like CSV, ICS, XML and JSON.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $events_import_export = em_get_more_extension_data('EventPrime MailPoet');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $events_import_export['url'];?>" class="open-plugin-details-modal" target="_blank">
                            EventPrime MailPoet
                            <img class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>event-mailpoet-icon.png"> 
                        </a>
                    </h3>
                </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li class="ep-free-extension-wrap"> 
                            <a class="ep-free-extension" href="<?php echo $events_import_export['url'];?>" target="_blank">Free</a>
                        </li>
                        <li><a class="install-now button <?php echo $events_import_export['class_name'];?>" href="<?php echo $events_import_export['url'];?>"><?php echo $events_import_export['button'];?></a></li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Connect and engage with your users by subscribing event attendees to MailPoet lists. Users can opt-in multiple newsletters during checkout and can also manage subscriptions in user account area.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $events_import_export = em_get_more_extension_data('WooCommerce Integration');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $events_import_export['url'];?>" class="open-plugin-details-modal" target="_blank">
                            WooCommerce Integration
                            <img class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-woo-icon.png"> 
                        </a>
                    </h3>
                </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li class="ep-free-extension-wrap"> 
                            <a class="ep-free-extension" href="<?php echo $events_import_export['url'];?>" target="_blank">Free</a>
                        </li>
                        <li><a class="install-now button <?php echo $events_import_export['class_name'];?>" href="<?php echo $events_import_export['url'];?>"><?php echo $events_import_export['button'];?></a></li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">This extension allows you to add optional and/ or mandatory products to your events. You can define quantity or let users chose it themselves. Fully integrates with EventPrime checkout experience and WooCommerce order management.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $events_zoom_integration = em_get_more_extension_data('EventPrime Zoom Integration');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $events_zoom_integration['url'];?>" class="open-plugin-details-modal" target="_blank">
                            EventPrime Zoom Integration
                            <img class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-zoom-icon.png"> 
                        </a>
                    </h3>
                </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li class="ep-free-extension-wrap"> 
                            <a class="ep-free-extension" href="<?php echo $events_zoom_integration['url'];?>" target="_blank">Beta</a>
                        </li>
                        <li><a class="install-now button <?php echo $events_zoom_integration['class_name'];?>" href="<?php echo $events_zoom_integration['url'];?>"><?php echo $events_zoom_integration['button'];?></a></li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">This extension seamlessly creates virtual events to be conducted on Zoom through the EventPrime plugin. The extension provides easy linking of your website to that of Zoom. Commence and let the attendees join the event with a single click.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
        <div class="plugin-card ep-ext-card">
            <div class="plugin-card-top">
                <?php $events_zapier_integration = em_get_more_extension_data('Zapier Integration');?>
                <div class="name column-name">
                    <h3>
                        <a href="<?php echo $events_zapier_integration['url'];?>" class="open-plugin-details-modal" target="_blank">
                            Zapier Integration
                            <img class="plugin-icon" alt="" src="<?php echo plugin_dir_url(__DIR__) . 'template/images/'; ?>ep-zapier-icon.png"> 
                        </a>
                    </h3>
                </div>
                <div class="action-links">
                    <ul class="plugin-action-buttons">
                        <li class="ep-free-extension-wrap"> 
                            <a class="ep-free-extension" href="<?php echo $events_zapier_integration['url'];?>" target="_blank">Beta</a>
                        </li>
                        <li><a class="install-now button <?php echo $events_zapier_integration['class_name'];?>" href="<?php echo $events_zapier_integration['url'];?>"><?php echo $events_zapier_integration['button'];?></a></li>
                    </ul>
                </div>
                <div class="desc column-description">
                    <p class="ep-col-desc">Extend the power of EventPrime using Zapier's powerful automation tools! Connect with over 3000 apps by building custom templates using EventPrime triggers.</p>
                    <p class="authors"> <cite>By <a target="_blank" href="https://eventprime.net/">eventprime</a></cite></p>
                </div>
            </div>
        </div>
    </div>
</div>