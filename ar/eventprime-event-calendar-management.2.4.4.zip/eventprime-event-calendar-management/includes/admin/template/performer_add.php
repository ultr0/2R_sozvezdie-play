<?php do_action('event_magic_admin_promotion_banner'); ?>
<div class="kikfyre kf-container"  ng-controller="performerCtrl" ng-app="eventMagicApp" ng-cloak ng-init="initialize('edit')">
    <div class="kf_progress_screen" ng-show="requestInProgress"></div>
    <div class="kf-db-content">

            <div class="kf-db-title">
                <?php _e('Performer(s)','eventprime-event-calendar-management'); ?>
            </div>

            <div class="form_errors">
                <ul>
                    <li class="emfield_error" ng-repeat="error in  formErrors">
                        <span>{{error}}</span>
                    </li>
                </ul>  
            </div>
        <!-- FORM -->
        <form name="postForm" ng-submit="savePerformer(postForm.$valid)" novalidate >
            
            <div class="emrow">
                <div class="emfield"> <?php _e('Performer Type','eventprime-event-calendar-management'); ?><sup>*</sup></div>
                <div class="eminput">
                    <ul class="emradio" >
                        <li ng-repeat="(key,value) in data.post.types">
                            <input required type="radio" name="type"  ng-model="data.post.type" value="{{value.key}}"> {{value.label}}
                        </li>
                    </ul>
                    <div class="emfield_error">
                        <span ng-show="postForm.title.$error.required && !postForm.title.$pristine"><?php _e('This is a required field.','eventprime-event-calendar-management'); ?></span>
                    </div>
                </div>
                <div class="emnote">
                    
                </div>
            </div>
            
            <div class="emrow">
                <div class="emfield"><?php _e('Name','eventprime-event-calendar-management'); ?><sup>*</sup></div>
                <div class="eminput">
                    <input  required  type="text" name="name"  ng-model="data.post.name">
                    <div class="emfield_error">
                         <span ng-show="postForm.name.$error.required && !postForm.name.$pristine"><?php _e('This is a required field.','eventprime-event-calendar-management'); ?></span>
                    </div>
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Person/Group name who is performing at event. Will be visible on Event page.','eventprime-event-calendar-management'); ?>
                </div>
            </div>
            
            <div class="emrow">
                <div class="emfield"><?php _e('Role','eventprime-event-calendar-management'); ?></div>
                <div class="eminput">
                    <input  type="text" name="role"  ng-model="data.post.role">
                    <div class="emfield_error">
                         
                    </div>
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Performer’s role. Example: Presenter, Stand-up comedian, musician, puppeteer, singer, etc.','eventprime-event-calendar-management'); ?>
                </div>
            </div>
            
            <div class="emrow">
                <div class="emfield"><?php _e('Cover Image','eventprime-event-calendar-management'); ?></div>
                <div class="eminput">
                    <input class="kf-upload" type="button" ng-click="mediaUploader(false)" value="<?php _e('Upload','eventprime-event-calendar-management'); ?>" />
                    <div class="em_cover_image em_gallery_images">
                     <img ng-src="{{data.post.feature_image}}" />
                    </div>
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Cover image of Performer. Will be displayed on Performer page.','eventprime-event-calendar-management'); ?>
                </div>
             </div>
            
          
            <div class="emrow kf-bg-light">
                <div class="emfield emeditor"><?php _e('Description','eventprime-event-calendar-management'); ?></div>
                <div class="eminput emeditor">
                    <?php 
                        $post_id= event_m_get_param('post_id');
                        $content='';
                        if($post_id!==null && (int)$post_id>0)
                        {
                            $post= get_post($post_id);
                            if(!empty($post))
                                $content= $post->post_content;
                        }
                        wp_editor($content,'description');
                    ?>
                </div>
                <div class="emnote emeditor">
                    <?php _e("Performer’s details.",'eventprime-event-calendar-management'); ?>
                </div>
             </div>
    
             <div class="emrow">
                <div class="emfield"><?php _e('Display on list of performers','eventprime-event-calendar-management'); ?></div>
                <div class="eminput">
                    <input  type="checkbox" name="display_front"  ng-model="data.post.display_front"  ng-true-value="'true'" ng-false-value="'false'">
                </div>
                <div class="emnote"><i class="fa fa-info-circle" aria-hidden="true"></i>
                    <?php _e('Hide/Show Performer in Performers directory.','eventprime-event-calendar-management'); ?>
                </div>
             </div>
            
            <input type="text" class="hidden" ng-model="post.feature_image_id" />
            <div class="dbfl kf-buttonarea">
            <div class="em_cancel"><a class="kf-cancel" href="<?php echo admin_url('/admin.php?page=em_performers') ?>">&#8592; &nbsp;<?php _e('Cancel','eventprime-event-calendar-management'); ?></a></div>
            <button type="submit" class="btn btn-primary" ng-disabled="postForm.$invalid || requestInProgress"><?php _e('Save','eventprime-event-calendar-management'); ?></button>
            </div>
            <div class="dbfl kf-required-errors" ng-show="postForm.$invalid && postForm.$dirty">
                <h3><?php _e("Looks like you missed out filling some required fields (*). You will not be able to save until all required fields are filled in. Here’s what's missing",'eventprime-event-calendar-management'); ?> - 
                <span ng-show="postForm.type.$error.required"><?php _e('Performer Type','eventprime-event-calendar-management'); ?></span>
                <span ng-show="postForm.name.$error.required"><?php _e('Name','eventprime-event-calendar-management'); ?></span>
                </h3>
            </div>
        </form>
            
</div>










