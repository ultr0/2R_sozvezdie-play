<!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->
<?php
wp_enqueue_script('em-public');
wp_enqueue_script('masonry');
wp_enqueue_style('masonry');
$event_service = EventM_Factory::get_service('EventM_Service');
global $wp;
if (event_m_get_param('em_types')) {
    $type_id = event_m_get_param('em_types');
    $type_service = EventM_Factory::get_service('EventTypeM_Service');
    $type_model = $type_service->load_model_from_db($type_id);
    if (!empty($type_model->id) && !empty($type_model->description)) {
        ?>    
        <div class="em_event_type_note">
            <?php echo $type_model->name; ?>
            <?php echo do_shortcode(wpautop($type_model->description)); ?>
        </div>
    <?php
    }
}
$currency_symbol = em_currency_symbol();
$request_data = $_REQUEST;
$view = isset($request_data['events_view']) ? $request_data['events_view'] : $events_atts['view'];
// set url for plain permalinks
$page_action = $form_action = '';
if(isset($request_data['page_id']) && !empty($request_data['page_id'])){
    $page_action = add_query_arg('page_id', $request_data['page_id'], $page_action);
    $form_action = add_query_arg('events_view', $view, $page_action);
}
else{
    $form_action = !empty($events_page_id) ? get_permalink($events_page_id) : "";
    $form_action = add_query_arg('events_view', $view, $form_action);
}
if(!empty($request_data['em_s'])){
    $view = (!empty($view)) ? $view : 'card';
    if(!empty($request_data['em_types']) && !is_array($request_data['em_types'])){
        $request_data['em_types']= explode(',', $request_data['em_types']);
    }
}
$current_ts = em_current_time_by_timezone();
$front_switch_view_option = $global_settings->front_switch_view_option;?>
<div class="emagic">
    <?php if ((isset($global_settings->disable_filter_options) && $global_settings->disable_filter_options == 0) || !isset($global_settings->disable_filter_options)) { ?>
    <form id="em_event_search_form" class="ep-event_search_form dbfl" name="em_event_search_form" action="<?php echo $form_action; ?>"> 
        <input type="text" name="events_view" value="<?php echo esc_attr($view);?>" style="display:none;">
        <div class="em_event_views_wrap dbfl" >
            <div class="em_event-filter-reset difl"><a href="<?php echo home_url($wp->request); ?>"><?php _e('Reset Filters', 'eventprime-event-calendar-management'); ?></a></div>
            <?php if(!empty($front_switch_view_option)){?>
                <div class="em_event_views difr">
                    <div class="ep-event-view-sort difl"><?php _e('View as', 'eventprime-event-calendar-management'); ?></div>
                    <?php //Profile Grid group ID  
                        $gid = isset($_REQUEST['gid']) ? '&gid='.absint($_REQUEST['gid']) : '';
                        $events_view_url = !empty($page_action) ? $page_action.'&events_view=' : '?events_view=';
                        //$events_view_url = get_permalink(em_global_settings("events_page")).$events_view_url;
                    ?>
                    <div class="ep-event-view-sort difl">
                        <div class="ep-sort-select-wrapper">
                            <div class="ep-sort-select">
                                <div class="ep-sort-select__trigger"><span><?php _e('Select View Type', 'eventprime-event-calendar-management'); ?></span>
                                    <div class="ep-sorting-arrow"></div>
                                </div>
                                <ul class="ep-sort-options">
                                    <?php if(in_array('day', $front_switch_view_option)){?>
                                        <li class="ep-sort-option <?php echo $view == 'day' ? 'selected' : ''; ?>" data-value="day" data-text="<?php _e('Day', 'eventprime-event-calendar-management'); ?>" data-url="<?php echo $events_view_url;?>day<?php echo $gid; ?>"><span class="difl"><i class="material-icons">today</i></span><?php _e('Day', 'eventprime-event-calendar-management'); ?></li><?php
                                    }
                                    if(in_array('week', $front_switch_view_option)){?>
                                        <li class="ep-sort-option <?php echo $view == 'week' ? 'selected' : ''; ?>" data-value="week" data-text="<?php _e('Week', 'eventprime-event-calendar-management'); ?>" data-url="<?php echo $events_view_url;?>week<?php echo $gid; ?>"><span class="difl"><i class="material-icons">date_range</i></span><?php _e('Week', 'eventprime-event-calendar-management'); ?></li><?php
                                    }
                                    if(in_array('month', $front_switch_view_option)){?>
                                        <li class="ep-sort-option <?php echo $view == 'month' ? 'selected' : ''; ?>" data-value="month" data-text="<?php _e('Month', 'eventprime-event-calendar-management'); ?>" data-url="<?php echo $events_view_url;?>month<?php echo $gid; ?>"><span class="difl"><i class="material-icons">date_range</i></span><?php _e('Month', 'eventprime-event-calendar-management'); ?></li><?php
                                    }
                                    if(in_array('listweek', $front_switch_view_option)){?>
                                        <li class="ep-sort-option <?php echo $view == 'listweek' ? 'selected' : ''; ?>" data-value="listweek" data-text="<?php _e('List Week', 'eventprime-event-calendar-management'); ?>" data-url="<?php echo $events_view_url;?>listweek<?php echo $gid; ?>"><span class="difl"><i class="material-icons">date_range</i></span><?php _e('List Week', 'eventprime-event-calendar-management'); ?></li>
                                        <?php
                                    }
                                    if(in_array('card', $front_switch_view_option)){?>
                                        <li class="ep-sort-option <?php echo $view == 'card' ? 'selected' : ''; ?>" data-value="card" data-text="<?php _e('Card', 'eventprime-event-calendar-management'); ?>" data-url="<?php echo $events_view_url;?>card<?php echo $gid; ?>"><span class="difl"><i class="material-icons">view_module</i></span><?php _e('Card', 'eventprime-event-calendar-management'); ?></li><?php
                                    }
                                    if(in_array('masonry', $front_switch_view_option)){?>
                                        <li class="ep-sort-option <?php echo $view == 'masonry' ? 'selected' : ''; ?>" data-value="masonry" data-text="<?php _e('Masonry', 'eventprime-event-calendar-management'); ?>" data-url="<?php echo $events_view_url;?>masonry<?php echo $gid; ?>"><span class="difl"><i class="material-icons">dashboard</i></span><?php _e('Masonry', 'eventprime-event-calendar-management'); ?></li><?php
                                    }
                                    if(in_array('slider', $front_switch_view_option)){?>
                                        <li class="ep-sort-option <?php echo $view == 'slider' ? 'selected' : ''; ?>" data-value="slider" data-text="<?php _e('Slider', 'eventprime-event-calendar-management'); ?>" data-url="<?php echo $events_view_url;?>slider<?php echo $gid; ?>"><span class="difl"><i class="material-icons">slideshow</i></span><?php _e('Slider', 'eventprime-event-calendar-management'); ?></li><?php
                                    }
                                    if(in_array('list', $front_switch_view_option)){?>
                                        <li class="ep-sort-option <?php echo $view == 'list' ? 'selected' : ''; ?>" data-value="list" data-text="<?php _e('List', 'eventprime-event-calendar-management'); ?>" data-url="<?php echo $events_view_url;?>list<?php echo $gid; ?>"><span class="difl"><i class="material-icons">view_list</i></span><?php _e('List', 'eventprime-event-calendar-management'); ?></li>
                                        <?php
                                    }?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div><?php
            }?>
        </div>
        <!-- Filter -->
        <button id="ep-filter-bar-collapse-toggle"  type="button">
            <span class="ep-filters-toggle-text-show"><?php _e('Show Event Search', 'eventprime-event-calendar-management'); ?></span>
            <span class="ep-filters-toggle-text-hide"><?php _e('Hide Event Search', 'eventprime-event-calendar-management'); ?></span>
            <span class="tribe-bar-toggle-arrow"></span>
        </button>
        <div id="ep-event-filterbar" class="ep-event-filters dbfl">
            <?php
            if(isset($request_data['page_id']) && !empty($request_data['page_id'])){?>
                <input type="hidden" name="page_id" value="<?php echo $request_data['page_id'];?>" /><?php
            }?>
            <div class="ep-event-filter-block difl">
                <div class="ep-event-filter-search">
                    <div class='ep-filter-label dbfl'><?php _e('Search by keyword', 'eventprime-event-calendar-management'); ?></div>
                    <input type="hidden" name="em_s" value="1" />
                    <input placeholder="<?php _e('Keyword', 'eventprime-event-calendar-management'); ?>" class="em_input" type="text" name="em_search" id="em_search" value="<?php $data = event_m_get_param('em_search'); echo $data; ?>" />
                </div>
            </div>
            <!-- <a class="em_hide_filter" ><?php _e('View and Hide Filter', 'eventprime-event-calendar-management'); ?></a>-->
            <div class="ep-event-filter-block difl">
                <div class="ep-event-types">
                    <div class="ep-filter-label"><?php echo __('Search by Event Type', 'eventprime-event-calendar-management'); ?></div>
                    <div class="ep-event-title ep_menu_item_visible"><?php _e('Event Type','eventprime-event-calendar-management'); ?></div>
                    <div class="ep-event-types-wrap ep_menu_item_hide">
                        <?php
                        $eventType_service = EventM_Factory::get_service('EventTypeM_Service');
                        if(isset($events_atts['types']) && !empty($events_atts['types']))
                            $types= $eventType_service->get_types(array('include'=>$events_atts['types']));
                        else
                            $types = $eventType_service->get_types();
                        $em_types = (array) event_m_get_param('em_types');
                        if (count($types) > 0):
                            foreach ($types as $type):?>
                                <div class="ep-event-type-block">
                                    <div class="em_radio">
                                        <input type="checkbox" <?php echo !empty($request_data['em_types']) ? in_array($type->id, $request_data['em_types']) ? 'checked' : '' :'' ?> class="em_type_option" name="em_types[]" value="<?php echo $type->id; ?>" <?php if (in_array($type->id, $em_types)) echo 'checked'; ?> id="<?php echo $type->id; ?>"style="background-color: <?php echo '#' . $type->color; ?>" />
                                        <label for="<?php echo $type->id; ?>"><?php echo $type->name; ?></label>
                                    </div>
                                </div>
                                <?php
                            endforeach;
                        endif;
                        ?> 
                    </div>
                </div>
            </div>
            <div class="ep-event-filter-block difl">
                <div class='start-end-date'>
                    <div class="ep-filter-label"> <?php echo __('Search by Date', 'eventprime-event-calendar-management'); ?></div>
                    <div class="ep-event-date"> 
                        <input type="text" placeholder="" readonly class="em_date" name="em_sd" value="<?php echo isset($_REQUEST['em_sd']) ? $_REQUEST['em_sd'] : ' '; ?>"/>
                    </div>
                </div>
            </div>

            <div class="ep-event-filter-block difl">
                <div class='ep-event-venue-filter'>
                    <div class="ep-filter-label"><?php echo __('Search by Event Site', 'eventprime-event-calendar-management'); ?></div>
                    <div class="ep-event-serach-venue">
                        <?php
                        $venue_service = EventM_Factory::get_service('EventM_Venue_Service');
                        if(isset($events_atts['sites']) && !empty($events_atts['sites']))
                            $all_venues= $venue_service->get_venues(array('include'=>$events_atts['sites']));
                        else
                            $all_venues = $venue_service->get_venues();
                        $selected_venue = isset($_REQUEST['em_venue']) ? $_REQUEST['em_venue'] : '';
                        if (count($all_venues) > 0):
                            ?>
                            <select name="em_venue">
                                <option value=""><?php _e('Event Site', 'eventprime-event-calendar-management'); ?></option>
                                <?php foreach ($all_venues as $venue): ?>
                                    <option <?php echo $selected_venue==$venue->id ? 'selected' : ''; ?>  value='<?php echo $venue->id; ?>'><?php echo $venue->name; ?></option>
                                    <?php
                                endforeach;
                                ?>
                            </select>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php do_action('em_event_filter_form'); ?>
            <div class="ep-event-filter-block difl">
                <div class="ep-event-filter-search_buttons">    
                    <input class="" type="submit" value="<?php _e('Search', 'eventprime-event-calendar-management'); ?>"/>
                </div>
            </div>
        </div>
    </form> 
    <?php } ?>
</div>  
<?php
switch ($view) {
    case 'listweek':
    case 'day':
    case 'week':
    case 'month': include('event_views/calendar.php');
        break;
    case 'masonry': include('event_views/masonry.php');
        break;
    case 'slider': include('event_views/slider.php');
        break;
    case 'list': include('event_views/list.php'); // Loading list view
        break;
    default: include('event_views/card.php'); // Loading card view
}
$em = event_magic_instance();
do_action('em_event_popup_data_scripts');
if (!in_array('event-comments',$em->extensions)) {
    add_filter('comments_array', '__return_empty_array', 10, 2);
}