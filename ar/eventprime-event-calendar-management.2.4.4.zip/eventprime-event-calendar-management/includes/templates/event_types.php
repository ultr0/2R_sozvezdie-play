<?php
    wp_enqueue_script('em-public');
    wp_enqueue_style('em-public-css');
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    $service = EventM_Factory::get_service('EventTypeM_Service');
    if(isset($atts['types'])){
        $page = false;
        $types = $atts['types'];
    } else{
        $types = $service->get_types(array('paged' => $paged,'offset'=> (int) ($paged-1) * EM_PAGINATION_LIMIT,'number'=>EM_PAGINATION_LIMIT));   
    }
    $types_page_url = get_permalink(em_global_settings("event_types"));
    $section_id = $column_class = $sec_unique = $class = '';
    if(isset($atts['section_id'])){
        $section_id = $atts['section_id'];
        $sec_unique = 'section-event-types-'.$section_id;
    }
    if(isset($atts['column_class'])){
        $column_class = $atts['column_class'];
    }
    if(isset($atts['class'])){
        $class = $atts['class'];
    }
?>
<div class="emagic <?php echo $class;?>" id="<?php echo $sec_unique;?>">
    <?php if (!empty($types)): ?>    
        <div class="ep-event-type-cards dbfl">
            <?php foreach($types as $type)
                {
                  include('event_type.php');  
                }
            ?>
        </div>
        <!-- Pagination -->
        <?php
            $total= $service->count(array('hide_empty' => false));
            $pages = ceil($total/EM_PAGINATION_LIMIT);
            // if there's more than one page
            if($pages>1){
                echo '<ul class="pagination">';
                for ($pagecount=1; $pagecount <= $pages; $pagecount++){
                    echo '<li><a href="'.get_permalink().'page/'.$pagecount.'/">'.$pagecount.'</a></li>';
                }
                echo '</ul>';  
            }
        ?>
        <!-- Pagination ends here -->
    <?php else: ?>
               
        <div class="ep-alert-warning ep-alert-info"><?php _e('No Event Type found','eventprime-event-calendar-management'); ?></div>
            
    <?php endif; ?>
</div>
<script>
    jQuery(document).ready(function(){
        $= jQuery;
        em_width_adjust(".em_performer");
        $('#addToCalendar').click(function () {
            $(this).attr("disabled", true);
        });
    });
</script>