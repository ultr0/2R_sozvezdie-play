<?php 
    wp_enqueue_style('em-public-css'); 
    wp_enqueue_script('em-public');
    $event_service = EventM_Factory::get_service('EventM_Service');
    $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
    $global_settings = $setting_service->load_model_from_db();
    $currency_symbol = em_currency_symbol();
    $organizer->count = $event_service->event_count_by_organizer($organizer->id);
    $events = $event_service->events_by_organizer($organizer->id);  
    $today = em_current_time_by_timezone();
    $showBookNowForGuestUsers = em_show_book_now_for_guest_users();
?>
<div class="emagic">
    <div class="em_content_area ep-event-type-single">
        <div class="ep-event-type-cover dbfl" style="border-bottom:3px solid">
            <img src="<?php if (isset($organizer->image_id)) echo wp_get_attachment_image_src($organizer->image_id, 'large')[0]; else echo esc_url(EM_BASE_FRONT_IMG_URL.'dummy_image.png'); ?>" alt="<?php _e('Event Organizer Image', 'eventprime-event-calendar-management'); ?>">
        </div>
        <div class="ep-event-type-head em_block dbfl">
            <div class="ep-event-type-name difl"><?php echo $organizer->name; ?></div>
        </div>
        <div class="ep-event-type-head em_block dbfl">
            <div class="ep-event-type-age"> 
                <span class="ep-event-type-title"><?php _e('Phone Number', 'eventprime-event-calendar-management'); ?></span> 
                <span><?php if (!empty($organizer->organizer_phones)) echo implode(', ',$organizer->organizer_phones); else _e('Not Available', 'eventprime-event-calendar-management'); ?></span>
            </div>
            <div class="ep-event-type-age"> 
                <span class="ep-event-type-title"><?php _e('Email Address', 'eventprime-event-calendar-management'); ?></span> 
                <span>
                    <?php if (!empty($organizer->organizer_emails)) {foreach($organizer->organizer_emails as $key => $val) {
                        $organizer->organizer_emails[$key] = '<a href="mailto:'.$val.'">'.htmlentities($val).'</a>';
                    }
                    echo implode(', ',$organizer->organizer_emails);} else _e('Not Available', 'eventprime-event-calendar-management'); ?>
                </span>
            </div>
            <div class="ep-event-type-age"> 
                <span class="ep-event-type-title"><?php _e('Website', 'eventprime-event-calendar-management'); ?></span> 
                <span>
                    <?php if (!empty($organizer->organizer_websites)) { foreach($organizer->organizer_websites as $key => $val) {
                        if(!empty($val)){
                            $organizer->organizer_websites[$key] = '<a href="'.$val.'" target="_blank">'.htmlentities($val).'</a>';
                        }
                    }
                    echo implode(', ',$organizer->organizer_websites);} else _e('Not Available', 'eventprime-event-calendar-management'); ?>
                </span>
            </div>
        </div>
        <div class="ep-event-type-instructions dbfl">
            <?php if (isset($organizer->description) && $organizer->description !== '') echo $organizer->description; else _e('No description available', 'eventprime-event-calendar-management'); ?>
        </div>
    </div>
    <?php 
    if(empty($hide_upcoming_events)){
        $upcoming_events = $event_service->upcoming_events_for_organizer($organizer->id);
        $event_service->print_upcoming_event_block($upcoming_events);
    }?>
</div>
<script>
    jQuery("#em-upcoming-event-load-more").click(function(){
        var total_count = jQuery(this).data('total_count');
        var current_count = jQuery(this).data('current_count');
        if(current_count < total_count){
            for(var i = 1; i < 6 ; i++){
                ++current_count;
                if(jQuery("#em-upcoming-"+current_count).length > -1){
                    jQuery("#em-upcoming-"+current_count).show();
                    jQuery("#em-upcoming-event-load-more").data('current_count', current_count);
                }
                if(current_count == total_count){
                    jQuery(".em-upcoming-event-load-more").hide();
                    return false;
                }
            }
        }
    });
</script>