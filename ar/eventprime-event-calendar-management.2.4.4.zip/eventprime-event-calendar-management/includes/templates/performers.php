<?php
wp_enqueue_style('em-public-css');
wp_enqueue_script('em-public');
$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
$args = array(
    'orderby' => 'date',
    'posts_per_page' => EM_PAGINATION_LIMIT,
    'offset'=> (int) ($paged-1) * EM_PAGINATION_LIMIT,
    'paged' => $paged,
    'meta_query' => array(	
        'relation' => 'OR',
        array(
            'key' => em_append_meta_key('display_front'),
            'value' => 1,
            'compare' => '='
        ),
        array(
            'key'     => em_append_meta_key('display_front'),
            'value'   => 'true',
            'compare' => '='
        )
    )
);
$service= EventM_Factory::get_service('EventM_Performer_Service');
$performers= $service->get_all($args);
$performers_page_url= get_permalink(em_global_settings("performers_page"));
$class = $section_id = $column_class = $sec_unique = '';
if(isset($atts['section_id'])){
    $section_id=$atts['section_id'];
    $sec_unique = 'section-performers-'.$section_id;
    $page = false;
}
if(isset($atts['class'])){
    $class = $atts['class'];
}
if(isset($atts['column_class'])){
    $column_class = $atts['column_class'];
}
?>

<div class="emagic <?php echo $class;?>" id="<?php echo $sec_unique;?>">
    <?php if (!empty($performers)) : ?>
        <div class="em_performers dbfl">
            <?php 
            foreach($performers as $performer){
                include('performer.php');
            }
            ?>
        </div>
        <?php
        unset($args['posts_per_page']);
        $total= $service->count($args);
        $pages = ceil($total/EM_PAGINATION_LIMIT);
        // if there's more than one page
        if($pages>1){
            echo '<ul class="pagination">';
            for ($pagecount=1; $pagecount <= $pages; $pagecount++){
                echo '<li><a href="'.get_permalink().'page/'.$pagecount.'/">'.$pagecount.'</a></li>';
            }
            echo '</ul>';  
        }?>
    <?php else: ?>
         <div class="ep-alert-warning ep-alert-info">
            <?php _e(' No performers found for the listed events.'); ?>
        </div><?php
    endif; ?>
</div>