<?php 
    wp_enqueue_style('em-public-css'); 
    wp_enqueue_script('em-public');
    $event_service = EventM_Factory::get_service('EventM_Service');
    $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
    $global_settings = $setting_service->load_model_from_db();
    $currency_symbol = em_currency_symbol();
    $type->count = $event_service->event_count_by_type($type->id);
    $events = $event_service->events_by_type($type->id);
    $today = em_current_time_by_timezone();
    $showBookNowForGuestUsers = em_show_book_now_for_guest_users();
    $class = $section_id = $sec_unique = '';
    $page = true;
    if(isset($atts['section_id'])){
        $section_id = $atts['section_id'];
        $sec_unique = 'section-event-type-'.$section_id;
        $page = false;
    }
    if(isset($atts['class'])){
        $class = $atts['class'];
    }
?>
<div class="emagic <?php echo $class;?>" id="<?php echo $sec_unique;?>">
    <div class="em_content_area ep-event-type-single">
        <div class="ep-event-type-cover dbfl" style="border-bottom:3px solid #<?php echo $type->color; ?>">
            <img src="<?php if (isset($type->image_id)) echo wp_get_attachment_image_src($type->image_id, 'large')[0]; else echo esc_url(EM_BASE_FRONT_IMG_URL.'dummy_image.png'); ?>" alt="<?php _e('Event Type Image', 'eventprime-event-calendar-management'); ?>">
        </div>
        <div class="ep-event-type-head em_block dbfl">
            <div class="ep-event-type-name difl"><?php echo $type->name; ?></div>
            <div class="ep-event-type-age difr"> <span class="ep-event-type-title"><?php _e('Age Group', 'eventprime-event-calendar-management'); ?></span> <span><?php if ($type->age_group !== 'custom_group') echo em_code_to_display_string($type->age_group); else _e($type->custom_group, 'eventprime-event-calendar-management'); ?></span> </div>
        </div>
        <div class="ep-event-type-instructions dbfl">
            <?php if (isset($type->description) && $type->description !== '') echo $type->description; else _e('No description available', 'eventprime-event-calendar-management'); ?>
        </div>
        <?php
        if(empty($hide_upcoming_events)){
            $event_service->print_upcoming_event_block($events);
        }?>
    </div>
</div>
<script>
    jQuery("#em-upcoming-event-load-more").click(function(){
        var total_count = jQuery(this).data('total_count');
        var current_count = jQuery(this).data('current_count');
        if(current_count < total_count){
            for(var i = 1; i < 6 ; i++){
                ++current_count;
                if(jQuery("#em-upcoming-"+current_count).length > -1){
                    jQuery("#em-upcoming-"+current_count).show();
                    jQuery("#em-upcoming-event-load-more").data('current_count', current_count);
                }
                if(current_count == total_count){
                    jQuery(".em-upcoming-event-load-more").hide();
                    return false;
                }
            }
        }
    });
</script>