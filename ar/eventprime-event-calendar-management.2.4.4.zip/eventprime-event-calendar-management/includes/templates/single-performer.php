<?php 
    wp_enqueue_style('em-public-css'); 
    wp_enqueue_script('em-public');
    $setting_service = EventM_Factory::get_service('EventM_Setting_Service');
    $global_settings= $setting_service->load_model_from_db();
    $service= EventM_Factory::get_service('EventM_Performer_Service');
    $performer= $service->load_model_from_db($post->ID);
    $booking_page_id = em_global_settings('booking_page');
    $event_service= EventM_Factory::get_service('EventM_Service');
    $profile   = em_global_settings('profile_page');
    $currency_symbol = em_currency_symbol();
    $showBookNowForGuestUsers = em_show_book_now_for_guest_users();
    $class = $section_id = $sec_unique = '';
    $page = true;
    if(isset($atts['section_id'])){
        $section_id = $atts['section_id'];
        $sec_unique = 'section-performers-'.$section_id;
        $page = false;
    }
    if(isset($atts['class'])){
        $class = $atts['class'];
    }
?>
<div class="emagic <?php echo $class;?>" id="<?php echo $sec_unique;?>">
    <!-- .content-area starts-->
    <div id="em_primary" class="em_content_area">
        <div id="post-<?php echo $performer->id; ?>">
            <div class="em_performer_profile dbfl">     
                <!---- Side-bar----->  
                 <div class="kf-event-cover dbfl">
                     <div class="kf-single-performer">
                         <img src="<?php if (!empty($performer->feature_image_id)) echo wp_get_attachment_image_src($performer->feature_image_id, 'large')[0]; else echo esc_url(plugins_url('/images/dummy-performer.png', __FILE__)); ?>" alt="<?php _e('Performer Feature Image','eventprime-event-calendar-management'); ?>" <?php if (empty($performer->feature_image_id)): echo 'class="em-no-image"'; endif?>>
                     </div>
                     <div class="ep-single-performer-head em_block dbfl">
                         <div class="kf-performer-name difl " title="<?php echo $performer->name; ?>"><?php echo $performer->name; ?></div>   
                     <?php if(isset($performer->role)): ?>                   
                             <div class="kf-performer-role em_color difr">
                                 <?php echo $performer->role; ?>
                             </div>
                         <?php endif; ?>   
                     </div>
                 </div>
                 <div class="ep-performer-description em_block dbfl">
                     <?php if (isset($performer->description) && $performer->description !== '') echo $performer->description; else _e('No desciption available','eventprime-event-calendar-management'); ?>
                 </div>
            </div>

            <?php 
            if(empty($hide_upcoming_events)){
                $upcoming_events = $event_service->upcoming_events_for_performer($performer->id);
                $event_service->print_upcoming_event_block($upcoming_events);
            }?>
        </div>
    </div>
</div>
<!-- .content-area ends-->
<script>
  jQuery("#em-upcoming-event-load-more").click(function(){
    var total_count = jQuery(this).data('total_count');
    var current_count = jQuery(this).data('current_count');
    if(current_count < total_count){
      for(var i = 1; i < 6 ; i++){
        ++current_count;
        if(jQuery("#em-upcoming-"+current_count).length > -1){
          jQuery("#em-upcoming-"+current_count).show();
          jQuery("#em-upcoming-event-load-more").data('current_count', current_count);
        }
        if(current_count == total_count){
          jQuery(".em-upcoming-event-load-more").hide();
          return false;
        }
      }
    }
  });
</script> 